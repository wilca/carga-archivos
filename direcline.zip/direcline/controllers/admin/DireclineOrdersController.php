<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to a commercial license from Jose Mª Gómez Roncer
 * Use, copy, modification or distribution of this source file without written
 * license agreement from the SARL SMC is strictly forbidden.
 * In order to obtain a license, please contact us: josemariagomezroncero@gmail.com
 * ...........................................................................
 * INFORMATION SUR LA LICENCE D'UTILISATION
 *
 * L'utilisation de ce fichier source est soumise a une licence commerciale
 * concedee par la societe Jose Mª Gómez Roncer
 * Toute utilisation, reproduction, modification ou distribution du present
 * fichier source sans contrat de licence ecrit de la part de la Jose Mª Gómez Roncero
 * expressement interdite.
 * Pour obtenir une licence, veuillez contacter Jose Mª Gómez Roncer a l'adresse: josemariagomezroncero@gmail.com
 *
 * @author    Jose Mª Gómez Roncer
 * @copyright Copyright (c) 2020 Jose Mª Gómez Roncero - Avda de Lorca nº 28 Bajo - Sangonera La Seca (España)
 * @license   Commercial license
 * @package   apmassociations
 * Support by mail:  josemariagomezroncero@gmail.com
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('DirecLineOders'))
    require_once(_PS_MODULE_DIR_.'direcline/classes/Direclineoders.php');

class DireclineOrdersController extends ModuleAdminController
{

    public function __construct()
    {

        $this->module = Module::getInstanceByName('direcline');

        $this->addJQuery();
        $this->addJS($this->module->getModulePath() . 'views/js/admin.js');

        $this->bootstrap = true;
        $this->name = 'DireclineOrders';
        $this->table = 'orders';
        $this->identifier = "id_order";
        $this->_defaultOrderWay = "DESC";
        $this->className = 'Order';
        $this->lang = false;
        $this->addRowAction('view');
        $this->explicitSelect = true;
        $this->allow_export = true;
        $this->deleted = false;
        $this->context = Context::getContext();
        $this->show_toolbar = false;
        $this->page_header_toolbar_btn = array();
        $this->position_identifier = 'id_order';

        $this->bulk_actions = array();

        $statuses = OrderState::getOrderStates((int) $this->context->language->id);
        foreach ($statuses as $status) {
            $this->statuses_array[$status['id_order_state']] = $status['name'];
        }
        
        $paquetes_divisor = (int)Configuration::get('DRCL_NPRODUCTS_BULT');


        $this->fields_list = array(
            'paquetes' => array(
                'enable' => false,
                'title' => $this->module->l('Paquetes'),
                'align' => 'left',
                'orderby' => false,
                'search' => false,
                'filter_key' => false,
                'class' => 'fixed-width-xs'
            ),
            'id_order' => array(
                'enable' => false,
                'title' => $this->module->l('ID'),
                'align' => 'left',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!id_order',
                'class' => 'fixed-width-xs'
            ),
            'reference' => array(
                'title' => $this->module->l('Referencia'),
                'align' => 'left',
                'orderby' => false,
            
                'search' => true,
                'filter_key' => 'a!reference'
            ),
            /*
            'name' => array(
                'title' => $this->module->l('Referencia'),
                'align' => 'left',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'c!name'
            ),
            */
            'customer' => array(
                'title' => $this->module->l('Cliente'),
                'align' => 'left',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'ad!customer'
            ),
            /*
            'name' => array(
                'title' => $this->module->l('País'),
                'align' => 'left',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'c!name'
            ),
            */
            'city' => array(
                'title' => $this->module->l('Ciudad'),
                'align' => 'left',
                'type' => 'price',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'ad!city'
            ),
            'total_paid' => array(
                'title' => $this->module->l('Total pagado'),
                'align' => 'left',
                'type' => 'price',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!total_paid'
            ),
            'total_shipping_tax_incl' => array(
                'title' => $this->module->l('Coste envío'),
                'align' => 'left',
                'type' => 'price',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!total_shipping_tax_incl'
            ),
            'osname' => array(
                'title' => $this->module->l('Status'),
                'type' => 'select',
                'color' => 'color',
                'list' => $this->statuses_array,
                'filter_key' => 'os!id_order_state',
                'filter_type' => 'int',
                'order_key' => 'osname',
            ),
            /*
            'tracking_number_n' => array(
                'title' => $this->module->l('Número de seguimiento'),
                'color' => 'tcolor',
                'align' => 'left',
                'orderby' => false,
                'search' => true,
                'class' => 'tracking_number_n',
                'filter_key' => 'oc!tracking_number_n'
            ),
            */
            'errors' => array(
                'type' => 'hidden',
                'color' => 'errorcolor',
                'hidden' => true,
                'title' => $this->module->l('Errores de envío'),
                'align' => 'left',
                'filter_key' => 'do!errors'
            ),
        );

        $this->_orderBy = 'id_order';
        $this->_orderWay = 'DESC';
        $this->_use_found_rows = true;

        $this->context->smarty->assign('controlador', 'AdminShippingReturns');
        $this->context->smarty->assign('displayName', $this->module->displayName);

        $url_module = $this->context->link->getAdminLink('AdminModules', false) . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&configure=' . 'direcline' . '&tab_module=' . $this->module->tab . '&module_name=' . 'direcline';
        $this->context->smarty->assign('url_module', $url_module);


        $this->_select = ''.
        ($paquetes_divisor > 0 ?
        '(SELECT CEIL(SUM(product_quantity) / ' . $paquetes_divisor . ') FROM ' . _DB_PREFIX_ . 'order_detail odd WHERE odd.id_order = a.id_order) as paquetes, ' :
        ' "1" as paquetes, '
        )
        . '
        CONCAT(ad.city, \'. \', ad.postcode, \'\') AS `city`,
        do.errors_html as errors,
        IF(do.errors_html LIKE "" OR do.errors_html is null, "transparent", "#8f0621") as errorcolor,
        IF(oc.tracking_number LIKE "" OR oc.tracking_number is null, "orange", "#32CD32") as tcolor,
        IF(oc.tracking_number LIKE "" OR oc.tracking_number is null, "Sin envío", oc.tracking_number) as tracking_number_n,
        IF(oc.tracking_number LIKE "" OR oc.tracking_number is null, 0, 1) as checkdisable,
		a.id_order AS id_order,
		CONCAT(LEFT(ad.`firstname`, 1), \'. \', ad.`lastname`) AS `customer`,
		osl.`name` AS `osname`,
		os.`color`,
		IF((SELECT so.id_order FROM `' . _DB_PREFIX_ . 'orders` so WHERE so.id_customer = a.id_customer AND so.id_order < a.id_order LIMIT 1) > 0, 0, 1) as new,
		c.name as cname,
		IF(a.valid, 1, 0) badge_success';

        $this->_join .= 
            ' LEFT JOIN ' . _DB_PREFIX_ . 'address ad ON ad.id_address = a.id_address_delivery ' .
            ' LEFT JOIN ' . _DB_PREFIX_ . 'order_state_lang s ON s.id_order_state = current_state AND s.id_lang=' . (int)Context::getContext()->language->id .
			' LEFT JOIN ' . _DB_PREFIX_ . 'country_lang c ON c.id_country = ad.id_country AND c.id_lang=' . (int)Context::getContext()->language->id . 
            ' LEFT JOIN ' . _DB_PREFIX_ . 'state st ON st.id_state = ad.id_state ' .
            ' INNER JOIN ' . _DB_PREFIX_ . 'order_carrier oc ON oc.id_order = a.id_order AND (oc.tracking_number LIKE "" OR oc.tracking_number is null) ' .
            ' LEFT JOIN `' . _DB_PREFIX_ . 'order_state` os ON (os.`id_order_state` = a.`current_state`) ' .
            ' LEFT JOIN `' . _DB_PREFIX_ . 'order_state_lang` osl ON (os.`id_order_state` = osl.`id_order_state` AND osl.`id_lang` = ' . (int) Context::getContext()->language->id . ')' . 
            ' LEFT JOIN `' . _DB_PREFIX_ . 'direcline_orders` do ON (do.`id_order` = a.`id_order`) ';
       

            
        $this->bulk_actions = array(
            'edit_order' => array('text' => $this->module->l('Change Order Status'), 'icon' => 'icon-refresh'),
        );
        
        Media::addJsDef(array(
            'directline_module_url' => $this->context->link->getAdminLink('DireclineOrders', false) . '&token=' . Tools::getValue('token') . '&configure=' . $this->module->name . '&tab_module=' . $this->module->tab . '&module_name=' . $this->module->name
        ));

        AdminController::__construct();
    }

    public function renderView()
    {
        $url = Context::getContext()->link->getAdminLink('AdminOrders');
        Tools::redirectAdmin($url . '&id_order='.(int)Tools::getValue('id_order').'&vieworder');
        die();
    }

    public function renderList()
    {
        $this->context->smarty->assign(array(
            'module_configured' => (Configuration::get('DRCL_ENABLED') == 1 && Configuration::get('DRCL_GUID') ? true: false),
        ));
        if (Tools::isSubmit('processMasive')) {
            unset($_POST['processMasive']);
            unset($_GET['processMasive']);
            $module = Module::getInstanceByName('direcline');
			return $module->processMasive($this);
		}
        if (Tools::getValue('action') == "edit_order") {
            $this->editOrder((int)Tools::getValue('id_order'));
            $url = Context::getContext()->link->getAdminLink('AdminOrders');
            Tools::redirectAdmin($url . '&id_order='.(int)Tools::getValue('id_order').'&vieworder');
            die();
        }
       // $html .= $this->module->hookAdminOrder(array());

        $html = parent::renderList();
        $this->context->smarty->assign(array(
            'list' => $this->_list,
        ));

        if (!Tools::getValue('ajax')) {
            $this->getTplVars();
            $html .= $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'direcline/views/templates/hook/admin_order.tpl');
            $html .= $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'direcline/views/templates/admin/orders.tpl');
        }

        $html .= $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'direcline/views/templates/admin/styles.tpl');

        return $html;
    }

    public function renderOnlyList() {
        $this->context->smarty->assign(array(
            'module_configured' => (Configuration::get('DRCL_ENABLED') == 1 && Configuration::get('DRCL_GUID') ? true: false),
        ));
        $html = parent::renderList();
        $this->context->smarty->assign(array(
            'list' => $this->_list,
        ));
        $html .= $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'direcline/views/templates/admin/styles.tpl');
        return $html;
    }

    public function getTplVars()
    {
        $this->context->smarty->assign(array(
            'Order' => new Order(),
            'DRCL_PAYREEM_MODULE'		=> explode(',', Configuration::get('DRCL_PAYREEM_MODULE')),
            'class_masive'              => 'col-xs-6',
            'ismasive'                  => true,
            'showExp'                   => false,
            'admin_order_errors_block'  => false,
            'module_dir' 				=> _PS_BASE_URL_ . __PS_BASE_URI__ . 'modules/' . $this->module->name . '/',
            'displayName' 				=> $this->module->displayName,
            'errors' 					=> false,
            'success' 					=> false,
            'debug' 					=> Configuration::get('DRCL_DEBUG'),
            'debugResult' 				=> Configuration::get('DRCL_DEBUG_RESULT'),
            'checkenabled' 				=> true,
            'expContent' 				=> Configuration::get('DRCL_EXPCONTENT'),
            'typeservice' 				=> unserialize(Configuration::get('DRCL_SERVICES_TYPE')),
            'reference' 				=> Configuration::get('DRCL_REFERENCE'),
            'paquets' 					=> 1,//(Configuration::get('DRCL_NPRODUCTS_BULT') > 1 ? Configuration::get('DRCL_NPRODUCTS_BULT') : 1),
            'cashdelivery' 				=> Configuration::get('DRCL_CASHDELIVERY'),
            'cashdelivery_value' 		=> Configuration::get('DRCL_CASHDELIVERY_VALUE'),
            'emailclient_value' 		=> Configuration::get('DRCL_EMAILCLIENT_VALUE'),
            'smsclient_value' 			=> Configuration::get('DRCL_SMSCLIENT_VALUE'),
            'emailshop_value' 			=> Configuration::get('PS_SHOP_EMAIL'),
            'saturdaydelivery' 			=> '',//Configuration::get('DRCL_SATURDAYDELIVERY'),
            'returnsend' 				=> Configuration::get('DRCL_RETURN_SEND'),
            'delegation' 				=> Configuration::get('DRCL_COLLECTION_DELEGATION'),
            'observations' 				=> Configuration::get('DRCL_OBSERVATIONS'),
            'festivedelivery'  			=> '',//Configuration::get('DRCL_FESTIVEDELIVERY'),
            'receiptaccuse'  			=> Configuration::get('DRCL_RECEIPT_ACCUSE'),
            'management'  				=> Configuration::get('DRCL_MANAGEMENT'),
            //'photoid'  				=> Configuration::get('DRCL_PHOTOID'),
            'insuredvalue'  			=> 0,//(Configuration::get('DRCL_INSURED_VALUE') > 0 ? 0 : 1),
            'insuredvalue_value'  		=> Configuration::get('DRCL_INSURED_VALUE'),
            'emailclient' 				=> 0,
            'smsclient' 				=> 0,
            'emailshop' 				=> 0,
            'postagedue' 				=> Configuration::get('DRCL_POSTAGE_DUE'),
            'sendexp_number' 			=> '',
            'sendexp_ref' 				=> '',
            'sendexp_status' 			=> '',
            'sendexp_date' 				=> '',
            'sendexp_hour' 				=> '',
            'sendexp_signature' 		=> '',
            'sendexp_dni' 				=> '',
            'sendexp_dateexp' 			=> '',
            'sendexp_name' 				=> '',
            'sendexp_remcity' 			=> '',
            'sendexp_dest' 				=> '',
            'sendexp_destaddress' 		=> '',
            'sendexp_destcp' 			=> '',
            'sendexp_destcity' 			=> '',
            'sendexp_destphone' 		=> '',
            'sendexp_observations' 		=> '',
            'sendexp_bults' 			=> '',
            'sendexp_peso' 				=> '',
            'sendexp_codeservices' 		=> '',
            'sendexp_idexp' 			=> '',
            'sendexp_viaref'			=> '',
            'sendexp_viatypeservice' 	=> '',
            'sendexp_codeagency' 		=> '',
            'sendexp_nameagency' 		=> '',
            'sendexp_phoneagency' 		=> '',
            'sendexp_nameagencyoring' 	=> '',
            'sendexp_abrev' 			=> '',
            'sendexp_saturdaydelivery'	=> '',
            'sendexp_festivedelivery'	=> '',
            'sendexp_management'  		=> '',
            'sendexp_returnsend' 		=> '',
            'sendexp_delegation' 		=> '',
            'sendexp_receiptaccuse'  	=> '',
            'showExp'  					=> '',
            'checkExp'  				=> '',

            ));
    }
}
