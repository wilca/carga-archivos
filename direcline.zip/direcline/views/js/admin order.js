/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to a commercial license from Jose Mª Gómez Roncero.
 * Use, copy, modification or distribution of this source file without written
 * license agreement from the SARL SMC is strictly forbidden.
 * In order to obtain a license, please contact us: josemariagomezroncero@gmail.com
 * ...........................................................................
 * INFORMATION SUR LA LICENCE D'UTILISATION
 *
 * L'utilisation de ce fichier source est soumise a une licence commerciale
 * concedee par la societe Jose Mª Gómez Roncero.
 * Toute utilisation, reproduction, modification ou distribution du present
 * fichier source sans contrat de licence ecrit de la part de la Jose Mª Gómez Roncero
 * expressement interdite.
 * Pour obtenir une licence, veuillez contacter Jose Mª Gómez Roncero. a l'adresse: josemariagomezroncero@gmail.com
 *
 * @author    Jose Mª Gómez Roncero.
 * @copyright Copyright (c) 2020 Jose Mª Gómez Roncero - Avda de Lorca nº 28 Bajo - Sangonera La Seca (España)
 * @license   Commercial license
 * @package   apmassociations
 * Support by mail:  josemariagomezroncero@gmail.com
*/


var direclineAdminorder = setInterval(function () {
    if (typeof ($) != 'undefined' && typeof ($) != undefined) {
        clearInterval(direclineAdminorder);
        $(document).ready(function () {
            getDirectlineOrder(this);
        });


        function getDirectlineOrder(object) {
            url = directline_module_url;
            datas = {};
            datas['id_order'] = id_order;
            $.ajax({
                url: url + "&getAjaxExpeditionForm",
                data: datas,
                type: 'POST',
                context: { url: url, obj: object }
            }).done(function (response, data, data2) {
                respuesta = jQuery.parseJSON(response);
                if (typeof (respuesta.closemodal) != 'undefined') {
                    $('#directModal').modal('toggle');
                }
                if (typeof (respuesta.ajaxcall) != 'undefined') {
                    setTimeout(function () {
                        direclineAdminProcess(this, respuesta.continue);
                    }, 100);
                }
                if ($(this.obj).hasClass('cacheAjax')) {
                    cacheAjax[this.url] = response;
                }
                if ($(this.obj).attr('blockobject') != 'undefined' && $(this.obj).attr('blockobject') != undefined) {
                    $($(object).attr('blockobject')).removeAttr('disabled');
                }
                if (typeof (respuesta.alert) != 'undefined') {
                    alert(respuesta.alert);
                }
                if (typeof (respuesta.textos) != 'undefined') {
                    for (i in respuesta.textos) {
                        $(i).first().replaceWith($(respuesta.textos[i]).find(i).first());
                    }
                }
                //  executeAjaxResponse(response, data, data2);
            });
        }
    }
})
