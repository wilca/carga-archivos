<?php
/*
* The MIT License (MIT)
*
* Copyright (c) 2017 Direcline Software © -  Ideasoft, S.L.U.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software && associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, && to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice && this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE && NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
*/
header("Content-Type: text/html;charset=utf-8");

if (!class_exists('DirecLineOders'))
	require_once(_PS_MODULE_DIR_ . 'direcline/classes/Direclineoders.php');

if (!defined('_PS_VERSION_'))
	exit;

class Direcline extends Module
{

	public $urlWebservice = '';
	public $urlTracing = '';
	private $bultoCodigoContenido = '';

	private $postErrors = array();
	private $postSuccess;

	private $StatusErr = 0;
	private $eOk = "0;1;2;4;8;16;32;64;128;256;512;1024;2048;4096;8192;16384;32768;65536;131072;262144;524288;1048576;2097152";

	public function __construct()
	{
		$this->name = 'direcline';
		$this->tab = 'shipping_logistics';
		$this->version = '0.1.4';
		$this->author = 'Direcline';
		$this->ps_versions_compliancy = array('min' => '1.4', 'max' => _PS_VERSION_);
		$this->error_file = _PS_MODULE_DIR_ . '/' . $this->name . '/debug.log';

		parent::__construct();
		$this->getClientConfig();
		if (Configuration::get('DRCL_ENABLED') == 1 && !Configuration::get('DRCL_USER') || !Configuration::get('DRCL_PASSWORD') || !Configuration::get('DRCL_URL_WEBSERVICE') || !Configuration::get('DRCL_URL_TRACING')) {
			$this->warning = $this->l('¡Revisa la configuración incompleta!');
		}
	}

	public function getClientConfig()
	{
		$configClient = file_get_contents(__DIR__ . '/configClient.json');
		$resultConfigClient = json_decode($configClient, true);
		$this->displayName = $resultConfigClient['moduleConfig']['moduleName'];
		$this->description = $resultConfigClient['moduleConfig']['moduleDescription'];
		$this->urlWebservice = $resultConfigClient['WSConfig']['URLWebService'];
		$this->urlTracing = $resultConfigClient['WSConfig']['URLTracing'];
		$this->bultoCodigoContenido = $resultConfigClient['OperativaConfig']['bultoCodigoContenido'];
	}

	public function install()
	{

		if (!parent::install() || !$this->registerHook('backOfficeHeader') || !$this->registerHook('AdminOrder') || !$this->installModuleTab()) {
			return false;
		}
		include(dirname(__FILE__) . '/sql/install.php');
		$this->getClientConfig();
		//Configuration::updateValue('DRCL_PHOTO_ID', 0);

		if (Configuration::get('DRCL_URL_WEBSERVICE') == '') {
			Configuration::updateValue('DRCL_URL_WEBSERVICE', $this->urlWebservice);
		}
		if (Configuration::get('DRCL_URL_TRACING') == '') {
			Configuration::updateValue('DRCL_URL_TRACING', $this->urlTracing);
		}
		return true;
	}


	function installModuleTab()
	{
		$tabs = array(
			array(
				'class_name' => 'DireclineOrders',
				'name' => 'Envíos con ' . $this->displayName,
				'idTabParent' => Tab::getIdFromClassName('AdminParentOrders')
			)
		);
		foreach ($tabs as $line) {
			$tab        = new Tab();
			$languages  = Language::getLanguages();
			foreach ($languages as $language) {
				$tab->{'name'}[(int)($language['id_lang'])] = $line['name'];
			}
			$tab->class_name    = $line['class_name'];
			$tab->module        = $this->name;
			$tab->id_parent     =  $line['idTabParent'];
			$tab->active        = 1;
			if (!$tab->save()) {
				return false;
			}
		}
		return true;
	}

	public function uninstall()
	{
		if (!parent::uninstall()) {
			return false;
		}
		if (Configuration::get('DRCL_USER') != "") {
			$this->desconectarUsuarioSOAP(Configuration::get('DRCL_USER'), Configuration::get('DRCL_PASSWORD'), 'uninstall');
		}
		
		//DATOS DEL ENVIO 
		Configuration::deleteByName('DRCL_ORDER_CASHDELIVERY');
		Configuration::deleteByName('DRCL_ORDER_CASHDELIVERY_VALUE');
		Configuration::deleteByName('DRCL_ORDER_CHECK_ENABLED');
		Configuration::deleteByName('DRCL_ORDER_DELEGATION');
		Configuration::deleteByName('DRCL_ORDER_EMAILCLIENT');
		Configuration::deleteByName('DRCL_ORDER_EMAILCLIENT_VALUE');
		Configuration::deleteByName('DRCL_ORDER_EMAILSHOP');
		Configuration::deleteByName('DRCL_ORDER_EMAILSHOP_VALUE');
		Configuration::deleteByName('DRCL_ORDER_EXPORDERID');
		//Configuration::deleteByName('DRCL_ORDER_FESTIVEDELIVERY'); 
		Configuration::deleteByName('DRCL_ORDER_INSUREDVALUE_VALUE');
		Configuration::deleteByName('DRCL_ORDER_MANAGEMENT');
		Configuration::deleteByName('DRCL_ORDER_NUMEXP');
		Configuration::deleteByName('DRCL_ORDER_OBSERVATIONS');
		Configuration::deleteByName('DRCL_ORDER_PAQUETS');
		Configuration::deleteByName('DRCL_ORDER_POSTAGEDUE');
		Configuration::deleteByName('DRCL_ORDER_RECEIPTACCUSE');
		Configuration::deleteByName('DRCL_ORDER_REFERENCE');
		Configuration::deleteByName('DRCL_ORDER_RETURNSEND');
		//Configuration::deleteByName('DRCL_ORDER_SATURDAYDELIVERY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_ABREV');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_BULTS');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_CODEAGENCY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_CODESERVICES');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DATE');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DATEEXP');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DEST');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DESTADDRESS');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DESTCITY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DESTCP');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DESTPHONE');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DNI');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_EMAILCLIENT');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_EMAILSHOP');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_HOUR');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_IDEXP');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_NAME');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_NAMEAGENCY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_NAMEAGENCYORING ');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_NUMBER');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_OBSERVATIONS');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_PESO');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_PHONEAGENCY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_POSTAGEDUE');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_REF');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_REMCITY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_SIGNATURE');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_SMSCLIENT');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_STATUS');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_VIAREF');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_VIATYPESERVICE');
		Configuration::deleteByName('DRCL_ORDER_SHIPPINGNUMBER');
		Configuration::deleteByName('DRCL_ORDER_SHOWEXP');
		Configuration::deleteByName('DRCL_ORDER_SMSCLIENT');
		Configuration::deleteByName('DRCL_ORDER_SMSCLIENT_VALUE');
		Configuration::deleteByName('DRCL_ORDER_TYPESERVICE');

		Configuration::deleteByName('DRCL_ENABLED');
		Configuration::deleteByName('DRCL_DEBUG');
		Configuration::deleteByName('DRCL_USER');
		Configuration::deleteByName('DRCL_PASSWORD');
		Configuration::deleteByName('DRCL_GUID');
		Configuration::deleteByName('DRCL_PAYREEM_MODULE');
		Configuration::deleteByName('DRCL_CURRENCY_ID');
		Configuration::deleteByName('DRCL_NPRODUCTS_BULT');
		Configuration::deleteByName('DRCL_STATUS_EMAILCLIENT');
		Configuration::deleteByName('DRCL_STATUS_SMSCLIENT');
		Configuration::deleteByName('DRCL_STATUS_EMAILSHOP');
		//Configuration::deleteByName('DRCL_DELIVERY_SATURDAY');
		//Configuration::deleteByName('DRCL_DELIVERY_FESTIVE');
		Configuration::deleteByName('DRCL_POSTAGE_DUE');
		Configuration::deleteByName('DRCL_RETURN_SEND');
		Configuration::deleteByName('DRCL_COLLECTION_DELEGATION');
		Configuration::deleteByName('DRCL_RECEIPT_ACCUSE');
		Configuration::deleteByName('DRCL_MANAGEMENT');
		//Configuration::deleteByName('DRCL_PHOTO_ID');
		Configuration::deleteByName('DRCL_INSURED_VALUE');
		Configuration::deleteByName('DRCL_AUTOCHANGE_STATUSSEND');
		Configuration::deleteByName('DRCL_AUTOSTATUSSEND');
		Configuration::deleteByName('DRCL_MANUALCHANGE_STATUSCANCEL');
		Configuration::deleteByName('DRCL_MANUALSTATUSCANCEL');
		Configuration::deleteByName('DRCL_CANARIAS_CODE');
		Configuration::deleteByName('DRCL_BALEARES_CODE');
		Configuration::deleteByName('DRCL_CEUTA_CODE');
		Configuration::deleteByName('DRCL_MELILLA_CODE');
		Configuration::deleteByName('DRCL_ANDORRA_CODE');
		Configuration::deleteByName('DRCL_GIBRALTAR_CODE');
		Configuration::deleteByName('DRCL_INTERNACIONAL_CODE');
		Configuration::deleteByName('DRCL_SERVICES_TYPE');
		Configuration::deleteByName('DRCL_URL_WEBSERVICE');
		Configuration::deleteByName('DRCL_URL_TRACING');
		Configuration::deleteByName('DRCL_ENABLED_CRON');
		Configuration::deleteByName('DRCL_STATUS_SEND_CRON');
		Configuration::deleteByName('DRCL_DEBUG_RESULT');
		Configuration::deleteByName('DRCL_STATUS_DELIVERED_CRON');
		Configuration::deleteByName('DRCL_STATUS_INCIDENCE_CRON');

		Configuration::deleteByName('DRCL_ORDER_SENDEXP_NAMEAGENCYORING');
		Configuration::deleteByName('DRCL_ORDER_INSUREDVALUE');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_MANAGEMENT');
		Configuration::deleteByName('DRCL_WEIGHT_UNIT');
		//Configuration::deleteByName('DRCL_ORDER_SENDEXP_SATURDAYDELIVERY');
		//Configuration::deleteByName('DRCL_ORDER_SENDEXP_FESTIVEDELIVERY');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_RETURNSEND');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_DELEGATION');
		Configuration::deleteByName('DRCL_ORDER_SENDEXP_RECEIPTACCUSE');

		return true;
	}

	public function getContent()
	{
		global $cookie, $smarty;

        if (Tools::isSubmit('getAjaxExpeditionForm')) {
			return $this->getAjaxExpeditionForm();
		}
		//if(!empty($_POST) && Tools::isSubmit('btnSubmit')) {
		if (filter_input_array(INPUT_POST) && Tools::isSubmit('btnSubmit')) {
			$this->getClientConfig();
			$this->postAdminValidator();
			if (empty($this->postErrors)) {
				$this->postSuccess = $this->l('La configuración se ha actualizado correctamente.');
			}
		}

		if (Tools::isSubmit('processMasive')) {
			return $this->processMasive();
		}
		$payments_modules = array();
		foreach (Module::getModulesOnDisk() as $module) {
			if ($module->tab == 'payments_gateways' && (!isset($module->not_on_disk) or !$module->not_on_disk)) {
				$payments_modules[] = (array)$module;
			}
		}

		$smarty->assign(array(
			'module_dir' => _PS_MODULE_DIR_ . $this->name,
			'displayname' => $this->displayName,
			'enabled' => Configuration::get('DRCL_ENABLED'),
			'debug' => Configuration::get('DRCL_DEBUG'),
			'user' => Configuration::get('DRCL_USER'),
			'password' => Configuration::get('DRCL_PASSWORD'),
			'payments_modules' => $payments_modules,
			'payreem_module' => Configuration::get('DRCL_PAYREEM_MODULE'),
			'currencies' => Currency::getCurrencies(),
			'currency_id' => Configuration::get('DRCL_CURRENCY_ID'),
			'nproducts_bult' => Configuration::get('DRCL_NPRODUCTS_BULT'),
			'weight_unit' => Configuration::get('DRCL_WEIGHT_UNIT'), //? Configuration::get('DRCL_WEIGHT_UNIT') : strtolower(Configuration::get('PS_WEIGHT_UNIT')),
			'ps_weight_unit' => strtolower(Configuration::get('PS_WEIGHT_UNIT')),
			'status_emailclient' => Configuration::get('DRCL_STATUS_EMAILCLIENT'),
			'status_smsclient' => Configuration::get('DRCL_STATUS_SMSCLIENT'),
			'status_emailshop' => Configuration::get('DRCL_STATUS_EMAILSHOP'),
			'delivery_saturday' => '', //Configuration::get('DRCL_DELIVERY_SATURDAY'),
			'delivery_festive' => '', //Configuration::get('DRCL_DELIVERY_FESTIVE'),
			'postage_due' => Configuration::get('DRCL_POSTAGE_DUE'),
			'return_send' => Configuration::get('DRCL_RETURN_SEND'),
			'collection_delegation' => Configuration::get('DRCL_COLLECTION_DELEGATION'),
			'receipt_accuse' => Configuration::get('DRCL_RECEIPT_ACCUSE'),
			'management' => Configuration::get('DRCL_MANAGEMENT'),
			//'photo_id' => Configuration::get('DRCL_PHOTO_ID'),
			'insured_value' => str_replace(',', '', Configuration::get('DRCL_INSURED_VALUE')),
			'states' => OrderState::getOrderStates((int)$cookie->id_lang),
			'autochange_statussend' => Configuration::get('DRCL_AUTOCHANGE_STATUSSEND'),
			'autostatussend' => Configuration::get('DRCL_AUTOSTATUSSEND'),
			'manualchange_statuscancel' => Configuration::get('DRCL_MANUALCHANGE_STATUSCANCEL'),
			'manualstatuscancel' => Configuration::get('DRCL_MANUALSTATUSCANCEL'),
			'canarias_code' => Configuration::get('DRCL_CANARIAS_CODE'),
			'baleares_code' => Configuration::get('DRCL_BALEARES_CODE'),
			'ceuta_code' => Configuration::get('DRCL_CEUTA_CODE'),
			'melilla_code' => Configuration::get('DRCL_MELILLA_CODE'),
			'andorra_code' => Configuration::get('DRCL_ANDORRA_CODE'),
			'gibraltar_code' => Configuration::get('DRCL_GIBRALTAR_CODE'),
			'internacional_code' => Configuration::get('DRCL_INTERNACIONAL_CODE'),
			'services' => Carrier::getCarriers((int)$cookie->id_lang, false, false, false, null, ALL_CARRIERS),
			'services_type' => unserialize(Configuration::get('DRCL_SERVICES_TYPE')),
			'url_webservice' => Configuration::get('DRCL_URL_WEBSERVICE'),
			'url_tracing' => Configuration::get('DRCL_URL_TRACING'),
			'RecogerCliente' => Configuration::get('RecogerCliente'),
			'cron_url' => _PS_BASE_URL_ . __PS_BASE_URI__ . 'modules/' . $this->name . '/cron.php?token=' . substr(_COOKIE_KEY_, 34, 8),
			'enabled_cron' => Configuration::get('DRCL_ENABLED_CRON'),
			'status_send_cron' => explode(";", Configuration::get('DRCL_STATUS_SEND_CRON')),
			'status_delivered_cron' => Configuration::get('DRCL_STATUS_DELIVERED_CRON'),
			'status_incidence_cron' => Configuration::get('DRCL_STATUS_INCIDENCE_CRON'),
			'postErrors' => $this->postErrors,
			'postSuccess' => $this->postSuccess,
			'url_locations' => $this->context->link->getAdminLink('AdminLocalization')
		));
		return $this->display(__FILE__, 'views/templates/hook/admin_config.tpl');
	}

	public function processMasive($DireclineOrdersController)
	{	
		if (!Tools::getValue('adm_order_typeservice')) {
			echo Tools::jsonEncode(array(
				'alert' =>  $this->l('Debe de seleccionar un Tipo de Servicio.'),
				'closemodal' => true
			));
			die;
		}
		$oders = Tools::getValue('orders');
		$paquetes = Tools::getValue('paquetes');
		if (Tools::getValue('oders_total')) {
			$oders_total = Tools::getValue('oders_total');
		} else {
			$oders_total = array();
		}
		if (Tools::getValue('oders_text')) {
			$oders_text = Tools::getValue('oders_text');
		} else {
			$oders_text = array();
		}
		if (!$oders && !Tools::getValue('continue')) {
			echo Tools::jsonEncode(array(
				'alert' =>  $this->l('Debe de seleccionar pedidos.'),
				'closemodal' => true
			));
			die;
		}

		$_POST['btnSubmitAdminOrder'] = true;
		$results = array();
		$i = 0;

		if (!class_exists('DireclineOrdersController')) {
			require_once(_PS_MODULE_DIR_ . 'direcline/controllers/admin/DireclineOrdersController.php');
		}
		//$DireclineOrdersController = new DireclineOrdersController();
		//$DireclineOrdersController->initHeader();
		$olders_send = '';
		//$_POST['adm_order_paquets_value'] = 1;
		$valores = Tools::getAllValues();
		foreach ($oders as $k => $l) {
			if ($l > 0) {
				$order = new Order($l);
				$address = new Address($order->id_address_delivery);
				$customer = new Customer($order->id_customer);
				$_POST['adm_order_reference'] = $_POST['adm_order_reference'] = $order->reference;
				$olders_send .= ' ' . $order->reference;
				$_POST['adm_order_emailclient_value'] = $customer->email;
				$_POST['adm_order_smsclient_value'] = ($address->phone_mobile ? $address->phone_mobile : $address->phone);
				if (Tools::getValue('adm_order_cashdelivery')) {
					$_POST['adm_order_cashdelivery_value'] = ($order->total_products_wt + $order->total_shipping_tax_incl);
				}
				if (Tools::getValue('adm_order_paquets')) {
					$_POST['adm_order_paquets_value'] = Tools::getValue('adm_order_paquets_value');
				} else {
					$_POST['adm_order_paquets_value'] = $paquetes[$l];
				}
				$trankingcode = $this->getTrackingNumber($l);
				if (!$trankingcode) {
					$this->hookAdminOrder(array(
						'id_order' => $l,
						'direclineajaxcall' => true,
					));
				}
				$trankingcode = $this->getTrackingNumber($l);
				if ($trankingcode) {
					$oders_text[$l] = $this->l('Pedido id: ') . $l . $this->l(' Referencia: ') . $order->reference . $this->l(' Número de seguimiento: ') . $trankingcode;
				} else {
					$oders_text[$l] = '<label style="color:red">' . $this->l('Error en pedido : ') . $l . $this->l(' Referencia: ') . $order->reference . '<label>';
				}
				/*	$DirecLineOders = new DirecLineOders($l);
				$DirecLineOders->id_order = $l;;
				$DirecLineOders->state = 1;
				$DirecLineOders->response = $results[$l];
				$DirecLineOders->errors = (count($this->admin_order_errors) > 0 ? json_encode($this->admin_order_errors) : false);
				$DirecLineOders->errors_html = (count($this->admin_order_errors) > 0 ? ($this->getErrorsHtml($this->admin_order_errors)) : false);
				if (!$results[$l]) {
					$this->admin_order_errors;
				}
				if ($DirecLineOders->id) {
					$r = $DirecLineOders->update();
				} else {
					$r = $DirecLineOders->add();
				}
				*/
				$oders_total[] = $oders[$k];
				unset($oders[$k]);
				if (count($this->admin_order_errors) > 0) {
					$valores['errors'] = $l;
					/*
					$results_json = array( 
						'response' => array(
							'#directModal .modal-body' => '<div class="modal-body"><div class="alert alert-danger ">' . $this->l('Error al enviar el pedido referencia ') . $order->reference . '<br>'. $this->getErrorsHtml($this->admin_order_errors) . '</div></div>',
							'#form-orders' => $DireclineOrdersController->renderOnlyList(),
						),
						'scrollto' => '#tr__' . $l . '_0'
					);
					echo Tools::jsonEncode($results_json);
					die;
					*/
				}
				$i += 1;
				if ($i > 5 || count($this->admin_order_errors) > 0) {
					$valores['orders'] = $oders;
					$valores['continue'] = true;
					$valores['oders_total'] = $oders_total;
					$valores['oders_text'] = $oders_text;
					$this->context->smarty->assign(array(
						'alerttype' => 'alert-warning',
						'oders_text' => $oders_text,
						'orders' => $oders_total,
						'msg' => $this->l('Continuando el envío de pedidos, no cierre esta página')
					));
					$results_json = array(
						'response' => array(
							'#directModal .modal-body' => $this->display(__FILE__, 'views/templates/admin/results.tpl'),// '<div class="modal-body"><div class="alert alert-success ">' . $this->l('Enviados los pedidos ') . '</div></div>',
							'#form-orders' => $DireclineOrdersController->renderOnlyList(),
						),
						'ajaxcall' => true,
						'continue' => $valores,
						'scrollto' => '#tr__' . $valores['errors'] . '_0'
					);
					echo Tools::jsonEncode($results_json);
					die;
				}
			}
		}

			$valores['orders'] = $oders_total;
			$valores['continue'] = true;
			$this->context->smarty->assign(array(
				'alerttype' => 'alert-success',
				'oders_text' => $oders_text,
				'orders' => $oders_total,
				'msg' => $this->l('Todos los pedidos han sido enviados')
			));
			if (isset($valores['errors'])) {
				$this->context->smarty->assign(array(
					'alerttype' => 'alert-danger',
					'msg' =>  $this->l('Ha habido errores en el envío de sus pedidos, compruebe la tabla.')
				));
			}
			echo Tools::jsonEncode(array(
				'response' => array(
					'#directModal .modal-body' => $this->display(__FILE__, 'views/templates/admin/results.tpl'),// '<div class="modal-body"><div class="alert alert-success">' . $this->l('Sus pedidos han sido enviados') . '</div></div>',
					'#form-orders' => $DireclineOrdersController->renderOnlyList(),
				)
			));

		die;
	}

	private function parseResults($results)
	{
		$trues = array(
			'GESTION', 'ENVIO_CON_RETORNO', 'RECOGIDA_EN_DELEGACION', 'ACUSE_RECIBO', 
		);
		foreach ($trues as $l) {
			if (property_exists($results, $l)) {
				if ($results->$l == 'true') {
					$results->$l = 1;
				} else {
					$results->$l = 0;
				}
			}
		}
		return $results;
	}

	public function getErrorsHtml($array) {
		$html = '';
		if (is_array($array)) {
			foreach ($array as $l) {
				$html .= $l . PHP_EOL;
			}
		}
		return $html;
	}

	public function hookBackOfficeHeader()
    {
        if (Tools::getValue('controller') == 'AdminOrders') {
			$this->context->controller->addJS($this->_path . '/views/js/admin order.js');
			Media::addJsDef(array(
				'id_order' => Tools::getValue('id_order'),
				'directline_module_url' => $this->context->link->getAdminLink('AdminModules', false) . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name
			));
        }
    }

	public function hookAdminOrder($params)
	{

		global $cookie, $smarty;
		$id_order = $params["id_order"];
		$drcl_datetime = new DateTime();
		$admin_order_errors = array();
		$admin_order_errors_block = array();
		$admin_order_success = '';
		$admin_order = new Order($id_order);
		$admin_order_carrier = new Carrier($admin_order->id_carrier);
		//$admin_order_state = new OrderState($cookie->id_lang);
		$admin_order_cart = new Cart($admin_order->id_cart);
		$admin_order_history = new OrderHistory();
		$admin_order_customer = new Customer($admin_order->id_customer);
		$admin_order_customer_address = new Address($admin_order->id_address_delivery);
		//$admin_order_customer_country = new Country($admin_order_customer_address->id_country);
		$order_carrier = new OrderCarrier($this->getIdOrderCarrier($admin_order));
		$DirecLineOders = new DirecLineOders($admin_order->id);
		$usgroup = 0;

		if (version_compare(_PS_VERSION_, '1.5', '>=')) {
			$reference = $admin_order->reference;
		} else {
			$reference = $admin_order->id;
		}

		//$shipped = $admin_order_state->delivery;

		if (Tools::getValue('adm_order_paquets_value') > 0) {
			/*
			$total_quantity = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT SUM(product_quantity) FROM ' . _DB_PREFIX_ . 'order_detail WHERE id_order = ' . (int) $admin_order->id);
			$total_quantity = ($total_quantity > 0 ? $total_quantity : 1);
			$paquetes = ceil($total_quantity / Tools::getValue('adm_order_paquets_value') );
			*/
			//$paquetes = ceil(Cart::getNbProducts($admin_order_cart->id) / Tools::getValue('adm_order_paquets_value') );
			/*
			if ($paquetes < 1) {
				$paquetes = 1;
			}
			*/
			$paquetes = Tools::getValue('adm_order_paquets_value');
		} else {
			if (Configuration::get('DRCL_NPRODUCTS_BULT') > 0) {
				$total_quantity = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT SUM(product_quantity) FROM ' . _DB_PREFIX_ . 'order_detail WHERE id_order = ' . (int) $admin_order->id);
				$total_quantity = ($total_quantity > 0 ? $total_quantity : 1);
				$paquetes = ceil($total_quantity / Configuration::get('DRCL_NPRODUCTS_BULT'));
				//$paquetes = ceil(Cart::getNbProducts($admin_order_cart->id) / Configuration::get('DRCL_NPRODUCTS_BULT'));
			} else {
				$paquetes = 1;
			}
		}
		$peso = $admin_order->getTotalWeight();
		if ($unit_weight = Configuration::get('DRCL_WEIGHT_UNIT')) {
			if ($unit_weight) {
				$unit_weight = strtolower($unit_weight);
				if ($unit_weight == 'gramo' || $unit_weight == 'gr' || $unit_weight == 'g') {
					$peso /= 1000;
				}
			}
		} else {
			$url_module = $this->context->link->getAdminLink('AdminModules', false) . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&configure=' . 'direcline' . '&tab_module=' . $obj->tab . '&module_name=' . 'direcline';
			$admin_order_errors_block[] = $this->l('Debe seleccionar una unidad de peso en su módulo') .
				' <a href="' . $url_module . '" target="_blank">' . $this->l('Configurelo desde este enlace') . '</a>';
		}

		Configuration::updateValue('DRCL_DEBUG_RESULT', '');
		Configuration::updateValue('DRCL_ORDER_CHECK_ENABLED', 0);
		Configuration::updateValue('DRCL_ORDER_TYPESERVICE', '');
		Configuration::updateValue('DRCL_ORDER_REFERENCE', $reference);
		Configuration::updateValue('DRCL_ORDER_PAQUETS', $paquetes);
		Configuration::updateValue('DRCL_ORDER_CASHDELIVERY', 0);
		Configuration::updateValue('DRCL_ORDER_CASHDELIVERY_VALUE', ($admin_order->total_products_wt + $admin_order->total_shipping_tax_incl));
		Configuration::updateValue('DRCL_ORDER_EMAILCLIENT', 0);//Configuration::get('DRCL_STATUS_EMAILCLIENT'));

		Configuration::updateValue('DRCL_ORDER_EMAILCLIENT_VALUE', $admin_order_customer->email);
		Configuration::updateValue('DRCL_ORDER_SMSCLIENT',  0);//Configuration::get('DRCL_STATUS_SMSCLIENT'));
		Configuration::updateValue('DRCL_ORDER_SMSCLIENT_VALUE', $admin_order_customer_address->phone_mobile);
		Configuration::updateValue('DRCL_ORDER_EMAILSHOP', 0);// Configuration::get('DRCL_STATUS_EMAILSHOP'));
		Configuration::updateValue('DRCL_ORDER_EMAILSHOP_VALUE', Configuration::get('PS_SHOP_EMAIL'));
		Configuration::updateValue('DRCL_ORDER_RECEIPTACCUSE', Configuration::get('DRCL_RECEIPT_ACCUSE'));
		Configuration::updateValue('DRCL_ORDER_MANAGEMENT', Configuration::get('DRCL_MANAGEMENT'));
		Configuration::updateValue('DRCL_ORDER_INSUREDVALUE_VALUE', Configuration::get('DRCL_INSURED_VALUE'));

		Configuration::updateValue('DRCL_ORDER_POSTAGEDUE', Configuration::get('DRCL_POSTAGE_DUE'));
		Configuration::updateValue('DRCL_ORDER_RETURNSEND', Configuration::get('DRCL_RETURN_SEND'));
		Configuration::updateValue('DRCL_ORDER_DELEGATION', Configuration::get('DRCL_COLLECTION_DELEGATION'));
		Configuration::updateValue('DRCL_ORDER_OBSERVATIONS', '');

		if (Tools::isSubmit('btnSubmitAdminOrder')) {
			Configuration::updateValue('DRCL_ORDER_CHECK_ENABLED', 1);
			if (!Tools::getValue('adm_order_typeservice')) {
				$admin_order_errors[] = $this->l('Tienes que seleccionar un "Tipo de Servicio".');
			} else {
				Configuration::updateValue('DRCL_ORDER_TYPESERVICE', Tools::getValue('adm_order_typeservice'));
			}
			
			Configuration::updateValue('DRCL_ORDER_REFERENCE', $reference);
			/* 14-11-2020 
			if (!Tools::getValue('adm_order_reference')) {
				$admin_order_errors[] = $this->l('Tienes que indicar una "Referencia".');
			} else {
				Configuration::updateValue('DRCL_ORDER_REFERENCE', Tools::getValue('adm_order_reference'));
			}
			*/
			Configuration::updateValue('DRCL_ORDER_PAQUETS', Tools::getValue('adm_order_paquets_value'));
			$paquetes = (int) Tools::getValue('adm_order_paquets_value');

			Configuration::updateValue('DRCL_ORDER_CASHDELIVERY', Tools::getValue('adm_order_cashdelivery'));
			Configuration::updateValue('DRCL_ORDER_CASHDELIVERY_VALUE', Tools::getValue('adm_order_cashdelivery_value'));

			Configuration::updateValue('DRCL_ORDER_EMAILCLIENT', Tools::getValue('adm_order_emailclient'));
			Configuration::updateValue('DRCL_ORDER_EMAILCLIENT_VALUE', Tools::getValue('adm_order_emailclient_value'));

			Configuration::updateValue('DRCL_ORDER_SMSCLIENT', Tools::getValue('adm_order_smsclient'));
			Configuration::updateValue('DRCL_ORDER_SMSCLIENT_VALUE', Tools::getValue('adm_order_smsclient_value'));

			$adm_order_date_send = strtotime (Tools::getValue('adm_order_date_send'));
			if ($adm_order_date_send < time()) {
				$adm_order_date_send = time();
			}
			$adm_order_date_send_time =   date('Y-m-d', $adm_order_date_send) . 'T' .  date('H:i:s');
			//$adm_order_date_send_time =  str_replace(' ', 'T', date('Y-m-d H:i:s', $adm_order_date_send));

			//Configuration::updateValue('DRCL_ORDER_DATE_SEND', str_replace(' ', 'T', $adm_order_date_send_time) . ':00+00:00');

			Configuration::updateValue('DRCL_ORDER_EMAILSHOP', Tools::getValue('adm_order_emailshop'));
			
			Configuration::updateValue('DRCL_ORDER_EMAILSHOP_VALUE', Tools::getValue('adm_order_emailshop_value'));
			//adm_order_receiptaccuse
			Configuration::updateValue('DRCL_ORDER_RECEIPTACCUSE', Tools::getValue('adm_order_receiptaccuse'));

			//adm_order_management
			Configuration::updateValue('DRCL_ORDER_MANAGEMENT', Tools::getValue('adm_order_management'));

			//adm_order_insuredvalue
			/*
			Configuration::updateValue('DRCL_ORDER_INSUREDVALUE', Tools::getValue('adm_order_insuredvalue'));
			if (Tools::getValue('adm_order_insuredvalue') == 1) {
				Configuration::updateValue('DRCL_ORDER_INSUREDVALUE_VALUE', Tools::getValue('adm_order_insuredvalue_value'));
			} else {
				Configuration::updateValue('DRCL_ORDER_INSUREDVALUE_VALUE', '0');
			}
*/



			Configuration::updateValue('DRCL_ORDER_POSTAGEDUE', Tools::getValue('adm_order_postagedue'));

			Configuration::updateValue('DRCL_ORDER_RETURNSEND', Tools::getValue('adm_order_returnsend'));

			Configuration::updateValue('DRCL_ORDER_DELEGATION', Tools::getValue('adm_order_delegation'));

			Configuration::updateValue('DRCL_ORDER_OBSERVATIONS', Tools::getValue('adm_order_observations'));

			$sumashop = 0;
			if (Tools::getValue('adm_order_emailshop')) {
				$val_array = explode(";", Configuration::get('DRCL_STATUS_EMAILSHOP')); //DRCL_ORDER_EMAILSHOP_VALUE
				$sumashop = array_sum($val_array);
				unset($val_array);
			}

			$sumaCli = 0;
			if (Tools::getValue('adm_order_emailclient')) {
				$val_array = explode(";", Configuration::get('DRCL_STATUS_EMAILCLIENT')); //DRCL_ORDER_EMAILCLIENT_VALUE
				$sumaCli = array_sum($val_array);
				unset($val_array);
			}
			$sumaSMS = 0;
			if (Tools::getValue('adm_order_smsclient')) {
				$val_array = explode(";", Configuration::get('DRCL_STATUS_SMSCLIENT')); //DRCL_ORDER_SMSCLIENT_VALUE
				$sumaSMS = array_sum($val_array);
				unset($val_array);
			}

			$RHFinal = new DateTime(date('H:i:s', strtotime("23:59:59")));

			if (empty($admin_order_errors)) {
				$result_grabarExpedicionExpres = $this->grabarExpedicionExpresSOAP(
					//GUID  ==> String
					Configuration::get('DRCL_GUID'),
					//Remitente ==> string 
					Configuration::get('PS_SHOP_NAME'),
					//RecogidaReferencia ==> string 
					Configuration::get('DRCL_ORDER_REFERENCE'),
					//RecogidaCodigoDomicilioMemorizado ==> string (opcional)
					'',
					//RecogidaDireccion ==> string 
					(trim(Configuration::get('PS_SHOP_ADDR1'))  != "" ? Configuration::get('PS_SHOP_ADDR1') : ''),
					//RecogidaTipoDireccion ==> string (opcional)
					'',
					//RecogidaNumeroDireccion ==> string (opcional)
					'',
					//RecogidaCodigoPostal ==> string 
					(trim(Configuration::get('PS_SHOP_CODE'))  != "" ? Configuration::get('PS_SHOP_CODE') : ''),
					//RecogidaPais ==> string 
					Configuration::get('PS_SHOP_COUNTRY'),
					//RecogidaPoblacion ==> string 
					(trim(Configuration::get('PS_SHOP_CITY'))  != "" ? Configuration::get('PS_SHOP_CITY') : ''),
					//RecogidaPisoDireccion ==> string (opcional)
					'',
					//RecogidaNombre2 ==> string (opcional)
					'',
					//RecogidaMasDatos ==> string
					(trim(Configuration::get('PS_SHOP_ADDR2'))  != "" ? Configuration::get('PS_SHOP_ADDR2') : ''),
					//RecogidaTelefono ==> string 
					(trim(Configuration::get('PS_SHOP_PHONE'))  != "" ? Configuration::get('PS_SHOP_PHONE') : ''),
					//RecogidaEmail ==> string 
					Configuration::get('DRCL_ORDER_EMAILSHOP_VALUE'),	//Configuration::get('PS_SHOP_EMAIL'),
					//RecogidaObservacion ==> string (opcional)
					'',
					//RecogidaMovil ==> string (opcional)
					'',
					//RecogidaNif ==> string (opcional)
					'',
					//RecogidaPointer ==> string (opcional)
					'',
					//RecogidaAvisoEmail ==> int 
					$sumashop,
					//RecogidaAvisoSms ==> int 
					'0',
					//RecogidaCodigoTipoServicio ==> string 
					Configuration::get('DRCL_ORDER_TYPESERVICE'),
					//RecogidaGestion ==> boolean 
					false,
					//RecogidaFecha ==> dateTime
					$adm_order_date_send_time,//$drcl_datetime->format('c'),
					//RecogidaHoraInicial ==> dateTime 
					$adm_order_date_send_time,//$drcl_datetime->format('c'),
					//RecogidaHoraFinal ==> dateTime 
					date('Y-m-d', $adm_order_date_send) . 'T23:59:59',//$RHFinal->format('c'),
					//RecogerCliente ==> boolean 
					(Configuration::get('RecogerCliente') ? true : false),
					//Destinatario ==> string 
					$admin_order_customer->firstname . ' ' . $admin_order_customer->lastname,
					//EntregaCodigoDomicilioMemorizado ==> string (opcional)
					'',
					//EntregaDireccion ==> string 
					$admin_order_customer_address->address1,
					//EntregaTipoDireccion ==> string (opcional)
					'',
					//EntregaNumeroDireccion ==> string (opcional)
					'',
					//EntregaCodigoPostal ==> string 
					$admin_order_customer_address->postcode,
					//EntregaPais ==> string 
					//$admin_order_customer_country->name[2],
					$admin_order_customer_address->country,
					//EntregaPoblacion ==> string 
					$admin_order_customer_address->city,
					//EntregaPisoDireccion ==> string (opcional)
					'',
					//EntregaNombre2 ==> string (opcional)
					'',
					//EntregaMasDatos ==> string
					$admin_order_customer_address->address2,
					//EntregaTelefono ==> string
					$admin_order_customer_address->phone,
					//EntregaEmail ==> string 
					Configuration::get('DRCL_ORDER_EMAILCLIENT_VALUE'),//$admin_order_customer->email,
					//EntregaObservacion ==> string 
					Configuration::get('DRCL_ORDER_OBSERVATIONS'),
					//EntregaMovil ==> string 
					Configuration::get('DRCL_ORDER_SMSCLIENT_VALUE'),//$admin_order_customer_address->phone_mobile,
					//EntregaNif ==> string 
					$admin_order_customer_address->dni,
					//EntregaPointer ==> string (opcional)
					'',
					//EntregaAvisoEmail ==> int --
					$sumaCli,
					//EntregaAvisoSms ==> int -- 
					$sumaSMS,
					//EntregaCodigoTipoServicio ==> string 
					Configuration::get('DRCL_ORDER_TYPESERVICE'),
					//EntregaGestion ==> boolean 
					Configuration::get('DRCL_ORDER_MANAGEMENT'),//Configuration::get('DRCL_ORDER_DELEGATION'), //Gestión
					//EntregaFecha ==> dateTime 
					$adm_order_date_send_time, //$drcl_datetime->format('c'),
					//Retorno ==> boolean 
					Configuration::get('DRCL_ORDER_RETURNSEND'),
					//AcuseRecibo ==> boolean --
					Configuration::get('DRCL_ORDER_RECEIPTACCUSE'),
					//ImporteValor ==> double 
					(Tools::getValue('adm_order_insuredvalue') == 1 ? str_replace(',', '.', Tools::getValue('adm_order_insuredvalue_value')) : '0.00'),//(Tools::getValue('adm_order_insuredvalue') == 1 ? str_replace(',', '.', Configuration::get('DRCL_ORDER_INSUREDVALUE_VALUE')) : '0.00'),
					//ImporteReembolso ==> double 
					(Tools::getValue('adm_order_cashdelivery') == 1 ? Configuration::get('DRCL_ORDER_CASHDELIVERY_VALUE') : '0.00'),
					//ImporteCobroACuenta ==> double 
					'0.00',
					//ImporteDebido ==> double
					(Tools::getValue('adm_order_postagedue')  == 1 ? 
						(Tools::getValue('adm_order_postagedue_value') ? Tools::getValue('adm_order_postagedue_value') :
							(property_exists($order_carrier, 'admin_order') ? round($order_carrier->total_shipping_tax_incl, 2) : round($admin_order->total_shipping_tax_incl, 2)) 
						): '0.00'),
					//BultoTotal ==> short 
					$paquetes,
					//BultoNumero ==> short
					array(1),
					//BultoAlto ==> float 
					array(0),
					//BultoAncho ==> float
					array(0),
					//BultoLargo ==> float 
					array(0),
					//BultoPeso ==> float 
					array($peso),
					//BultoCodigoContenido ==> string 
					array($this->bultoCodigoContenido),
					//BultoObservacion ==> string 
					array(''),
					//BultoReferencia ==> string 
					array(''),
					//Referencia ==> string 
					Configuration::get('DRCL_ORDER_REFERENCE') 
				);

				if ($result_grabarExpedicionExpres->ERROR) {
					switch ($result_grabarExpedicionExpres->ERROR->CODIGO) {
						case "3":
							$this->getNewGUID();
							if (!isset($params['norepeat'])) {
								$params['norepeat'] = true;
								$this->hookAdminOrder($params); //esto es un bucle
							} else {
								$admin_order_errors[] = $this->l('No ha sido posible contectar. Espere unos minutos, si el problema persiste contacte con su proveedor');
							}
							break;
						case "800027":
							$admin_order_errors[] = $this->l(utf8_decode($result_grabarExpedicionExpres->ERROR->MENSAJE));
							break;
						default:
							$usErr = array();
							$admErr = array();
							foreach ($result_grabarExpedicionExpres as $err) {
								switch ($err->CODIGO) {
									case "802":
										$ms = $this->getMessage($err->MENSAJE);
										if ($ms != "") {
											if (empty($usErr))
												$usgroup = 1;

											$usErr[] = $this->l($ms . ".");
										} else {
											//transforma a minúsculas
											$admErr[] = $this->l(mb_strtolower(utf8_decode($result_grabarExpedicionExpres->ERROR->MENSAJE), 'UTF-8') . " (" . $result_grabarExpedicionExpres->ERROR->CODIGO . "). Contacte con su oficina de mensajería.");
										}
										break;
									default:
										//transforma a minúsculas
										$admErr[] = $this->l(mb_strtolower(utf8_decode($result_grabarExpedicionExpres->ERROR->MENSAJE), 'UTF-8') . " (" . $result_grabarExpedicionExpres->ERROR->CODIGO . "). Contacte con su oficina de mensajería.");
										break;
								}
							}
							if (empty($admErr) == false)
								$admin_order_errors = $admErr;
							if (empty($usErr) == false)
								$admin_order_errors = $usErr;

							break;
					}
				} else {
					$numRef = $result_grabarExpedicionExpres->EXPEDICION->REFERENCIAENTREGA;
					$result_obtenerExpedicion = $this->obtenerExpedicionECommerceSOAP($numRef);

					if ($result_obtenerExpedicion->ERROR) {

						if ($result_obtenerExpedicion->ERROR->CODIGO == 800027)
							$admin_order_errors[] = $this->l(utf8_decode($result_obtenerExpedicion->ERROR->MENSAJE));
						else
							$admin_order_errors[] = $this->getCodeError($result_obtenerExpedicion->ERROR->CODIGO, $result_obtenerExpedicion->ERROR->MENSAJE);
					} else {
						$this->setTrackingNumber($id_order, $numRef);
						$this->actualizarUrlOrderCarrier($admin_order_carrier);

						//Configuration::updateValue('DRCL_ORDER_SHOWEXP', 1);
						Configuration::updateValue('DRCL_ORDER_EXPORDERID', $admin_order->id); //Configuration::get('DRCL_ORDER_REFERENCE')
						Configuration::updateValue('DRCL_ORDER_NUMEXP', $numRef);
						$xmlResultGrabarExp = $result_obtenerExpedicion->EXPEDICION;
						/* 14-11-2020
						Configuration::updateValue('DRCL_ORDER_SENDEXP_NUMBER', $xmlResultGrabarExp->NUMERO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_REF', $xmlResultGrabarExp->REFERENCIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_STATUS', $xmlResultGrabarExp->ESTADO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DATE', $xmlResultGrabarExp->FECHA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_HOUR', $xmlResultGrabarExp->HORA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_SIGNATURE', $xmlResultGrabarExp->FIRMA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DNI', $xmlResultGrabarExp->DNI);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DATEEXP', $xmlResultGrabarExp->FECHAEXPEDICION);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_NAME', $xmlResultGrabarExp->NOMBRE);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_REMCITY', $xmlResultGrabarExp->POBLACION_REMITENTE);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DEST', $xmlResultGrabarExp->DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DESTADDRESS', $xmlResultGrabarExp->DOMICILIO_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DESTCP', $xmlResultGrabarExp->CDP_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DESTCITY', $xmlResultGrabarExp->POBLACION_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DESTPHONE', $xmlResultGrabarExp->TELEFONO_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_OBSERVATIONS', $xmlResultGrabarExp->OBSERVACIONES);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_BULTS', $xmlResultGrabarExp->BULTOS);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_PESO', $xmlResultGrabarExp->PESO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_CODESERVICES', $xmlResultGrabarExp->CODIGO_TIPOSERVICIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_IDEXP', $xmlResultGrabarExp->IDEXPEDICION);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_VIAREF', $xmlResultGrabarExp->REFERENCIA_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_VIATYPESERVICE', $xmlResultGrabarExp->TIPO_SERVICIO_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_CODEAGENCY', $xmlResultGrabarExp->CODIGO_AGENCIA_DESTINO_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_NAMEAGENCY', $xmlResultGrabarExp->NOMBRE_AGENCIA_DESTINO_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_PHONEAGENCY', $xmlResultGrabarExp->TELEFONO_AGENCIA_DESTINO_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_NAMEAGENCYORING', $xmlResultGrabarExp->NOMBRE_AGENCIA_ORIGEN_VIA);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_ABREV', $xmlResultGrabarExp->ABREVIATURA);

						Configuration::updateValue('DRCL_ORDER_SENDEXP_EMAILSHOP', $xmlResultGrabarExp->ENVIO_EMAIL_REMITENTE);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_SMSCLIENT', $xmlResultGrabarExp->ENVIO_SMS_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_EMAILCLIENT', $xmlResultGrabarExp->ENVIO_EMAIL_DESTINATARIO);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_POSTAGEDUE', $xmlResultGrabarExp->IMPORTE_DEBIDO);

						Configuration::updateValue('DRCL_ORDER_SENDEXP_MANAGEMENT', (trim(strtolower($xmlResultGrabarExp->GESTION)) == 'true') ? 1 : 0);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_RETURNSEND', (trim(strtolower($xmlResultGrabarExp->ENVIO_CON_RETORNO)) == 'true') ? 1 : 0);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_DELEGATION', (trim(strtolower($xmlResultGrabarExp->RECOGIDA_EN_DELEGACION)) == 'true') ? 1 : 0);
						Configuration::updateValue('DRCL_ORDER_SENDEXP_RECEIPTACCUSE', (trim(strtolower($xmlResultGrabarExp->ACUSE_RECIBO)) == 'true') ? 1 : 0);
						*/


						if (Configuration::get('DRCL_AUTOCHANGE_STATUSSEND') == 1) {
							$admin_order_history->id_order = $admin_order->id;
							$admin_order_history->id_employee = $cookie->id_employee;
							$admin_order_history->changeIdOrderState(Configuration::get('DRCL_AUTOSTATUSSEND'), $admin_order, true);
							$admin_order_history->addWithemail();
							header("Refresh:0");
						}
					}
				}
			}
			$DirecLineOders->id_order = $admin_order->id;
			$DirecLineOders->state = 1;
			$DirecLineOders->response = Tools::jsonEncode($this->parseResults($result_obtenerExpedicion->EXPEDICION));
			$DirecLineOders->errors = (count($admin_order_errors) > 0 ? json_encode($admin_order_errors) : false);
			$DirecLineOders->errors_html = $this->getErrorsHtml($admin_order_errors);
			if ($DirecLineOders->id && $DirecLineOders->date_add) {
				$r = $DirecLineOders->update();
			} else {
				$r = $DirecLineOders->add();
			}
		}

		//Esta accion es la que se produce al modificar el numero de seguimiento de forma manual en la configuracion del Transporte 1 dentro del pedido y guardar.
		if (Tools::isSubmit('submitShippingNumber')) {
			//En la version 1.7 ademas deja cambiar el transportista
			if (version_compare(_PS_VERSION_, '1.7', '<')) {
				$this->actualizarUrlOrderCarrier($admin_order_carrier);
			}
		}

		//Botón de imprimir etiqueta
		if (Tools::isSubmit('btnSubmitAdminOrderPrint')) {
			$NumExp = $this->getTrackingNumber($id_order);
			$result_imprimirEtiqueta = $this->imprimirEtiquetaSOAP(Configuration::get('DRCL_GUID'), $NumExp);
			if ($result_imprimirEtiqueta->ERROR) {

				if ($result_imprimirEtiqueta->ERROR->CODIGO == 800027)
					$admin_order_errors[] = $this->l(utf8_decode($result_imprimirEtiqueta->ERROR->MENSAJE));
				else
					$admin_order_errors[] = $this->getCodeError($result_imprimirEtiqueta->ERROR->CODIGO, $result_imprimirEtiqueta->ERROR->MENSAJE);
			} else {
				$getPDF = base64_decode($result_imprimirEtiqueta);
				header('Content-Transfer-Encoding: binary');
				header('Content-Type: application/pdf');
			//	header('Content-Disposition: attachment; filename="etiqueta_CU' . str_pad($admin_order->invoice_number, 6, "0", STR_PAD_LEFT) . '.pdf"');
				header('Content-Disposition: attachment; filename="Etiqueta_Pedido' . $admin_order->id . '_Expedicion' . $NumExp . '.pdf"');
				ob_end_clean();
				echo $getPDF;
			}
		}

		//Botón de cancelar envio
		if (Tools::isSubmit('btnSubmitAdminOrderCancel')) {
			$NumExp = $this->getTrackingNumber($id_order);
			$result_eliminarExpedicion = $this->eliminarExpedicionSOAP(Configuration::get('DRCL_GUID'), $NumExp);
			if ($result_eliminarExpedicion->ERROR) {

				if ($result_eliminarExpedicion->ERROR->CODIGO == 800027)
					$admin_order_errors[] = $this->l(utf8_decode($result_eliminarExpedicion->ERROR->MENSAJE));
				else
					$admin_order_errors[] = $this->getCodeError($result_eliminarExpedicion->ERROR->CODIGO, $result_eliminarExpedicion->ERROR->MENSAJE);
			} else {
				if ($DirecLineOders->exist()) {
					$DirecLineOders->delete();
				}
				if (Configuration::get('DRCL_MANUALCHANGE_STATUSCANCEL') == 1) {
					$admin_order_history->id_order = $admin_order->id;
					$admin_order_history->id_employee = $cookie->id_employee;
					$admin_order_history->changeIdOrderState(Configuration::get('DRCL_MANUALSTATUSCANCEL'), $admin_order, true);
					$admin_order_history->addWithemail();
				}
				Configuration::deleteByName('DRCL_ORDER_EXPORDERID');
				Configuration::deleteByName('DRCL_ORDER_SHOWEXP');
				Configuration::deleteByName('DRCL_ORDER_EXPCONTENT');
				$this->deleteTrackingNumber($id_order);
				header("Refresh:0");
			}
			if (Configuration::get('DRCL_DEBUG') == 1) {
				ob_start();
				Configuration::updateValue('DRCL_DEBUG_RESULT', var_export($result_eliminarExpedicion, true));
				ob_end_flush();
			}
		}

		if (Configuration::get('DRCL_ENABLED') == 1 && Configuration::get('DRCL_GUID')) {
			$number = $this->getTrackingNumber($id_order);

			$smarty->assign(array(
				'Order' => $admin_order,
				'DRCL_PAYREEM_MODULE'		=> explode(',', Configuration::get('DRCL_PAYREEM_MODULE')),
				'class_masive'              => 'col-xs-6',
				'ismasive'                  => false,
				'admin_order_errors_block' => $admin_order_errors_block,
				'module_dir' 				=> _PS_MODULE_DIR_ . $this->name,
				'displayName' 				=> $this->displayName,
				'errors' 					=> $admin_order_errors,
				'success' 					=> $admin_order_success,
				'debug' 					=> Configuration::get('DRCL_DEBUG'),
				'debugResult' 				=> Configuration::get('DRCL_DEBUG_RESULT'),
				'checkenabled' 				=> (($DirecLineOders->response && $DirecLineOders->response != 'null') || Tools::getValue('checkCfgSend') ? 1 : 0), //Configuration::get('DRCL_ORDER_CHECK_ENABLED'),
				'expContent' 				=> Configuration::get('DRCL_ORDER_EXPCONTENT'),
				'typeservice' 				=> unserialize(Configuration::get('DRCL_SERVICES_TYPE')),
				'reference' 				=> Configuration::get('DRCL_ORDER_REFERENCE'),
				'paquets' 					=> Configuration::get('DRCL_ORDER_PAQUETS'),
				'cashdelivery' 				=> Configuration::get('DRCL_ORDER_CASHDELIVERY'),
				'cashdelivery_value' 		=> Configuration::get('DRCL_ORDER_CASHDELIVERY_VALUE'),
				'emailclient_value' 		=> Configuration::get('DRCL_ORDER_EMAILCLIENT_VALUE'),
				'smsclient_value' 			=> Configuration::get('DRCL_ORDER_SMSCLIENT_VALUE'),
				'emailshop_value' 			=> Configuration::get('DRCL_ORDER_EMAILSHOP_VALUE'),
				'saturdaydelivery' 			=> '', //Configuration::get('DRCL_ORDER_SATURDAYDELIVERY'),
				'returnsend' 				=> Configuration::get('DRCL_ORDER_RETURNSEND'),
				'postagedue' 				=> Configuration::get('DRCL_ORDER_POSTAGEDUE'),
				'delegation' 				=> Configuration::get('DRCL_ORDER_DELEGATION'),
				'observations' 				=> Configuration::get('DRCL_ORDER_OBSERVATIONS'),
				'festivedelivery'  			=> '', //Configuration::get('DRCL_ORDER_FESTIVEDELIVERY'),
				'receiptaccuse'  			=> Configuration::get('DRCL_ORDER_RECEIPTACCUSE'),
				'management'  				=> Configuration::get('DRCL_ORDER_MANAGEMENT'),
				//'photoid'  				=> Configuration::get('DRCL_ORDER_PHOTOID'),
				'insuredvalue'  			=> 0,//(Configuration::get('DRCL_INSURED_VALUE') > 0 ? 0 : 1),
				'insuredvalue_value'  		=> Configuration::get('DRCL_INSURED_VALUE'),//Configuration::get('DRCL_ORDER_INSUREDVALUE_VALUE'),
				'emailclient' 				=> Configuration::get('DRCL_ORDER_EMAILCLIENT'),
				'smsclient' 				=> Configuration::get('DRCL_ORDER_SMSCLIENT'),
				'emailshop' 				=> Configuration::get('DRCL_ORDER_EMAILSHOP'),
				'sendexp_number' 			=> '',
				'sendexp_ref' 				=> '',
				'sendexp_status' 			=> '',
				'sendexp_date' 				=> '',
				'sendexp_hour' 				=> '',
				'sendexp_signature' 		=> '',
				'sendexp_dni' 				=> '',
				'sendexp_dateexp' 			=> '',
				'sendexp_name' 				=> '',
				'sendexp_remcity' 			=> '',
				'sendexp_dest' 				=> '',
				'sendexp_destaddress' 		=> '',
				'sendexp_destcp' 			=> '',
				'sendexp_destcity' 			=> '',
				'sendexp_destphone' 		=> '',
				'sendexp_observations' 		=> '',
				'sendexp_bults' 			=> '',
				'sendexp_peso' 				=> '',
				'sendexp_codeservices' 		=> '',
				'sendexp_idexp' 			=> '',
				'sendexp_viaref'			=> '',
				'sendexp_viatypeservice' 	=> '',
				'sendexp_codeagency' 		=> '',
				'sendexp_nameagency' 		=> '',
				'sendexp_phoneagency' 		=> '',
				'sendexp_nameagencyoring' 	=> '',
				'sendexp_abrev' 			=> '',
				'sendexp_saturdaydelivery'	=> '',
				'sendexp_festivedelivery'	=> '',
				'sendexp_management'  		=> '',
				'sendexp_returnsend' 		=> '',
				'sendexp_delegation' 		=> '',
				'sendexp_receiptaccuse'  	=> '',
				'showExp'  					=> '',
				'checkExp'  				=> '',
			));

			/*
			if ($number != '' && Configuration::get('DRCL_ORDER_CHECK_ENABLED') == 0) {
				$this->StatusErr = 0;
				$this->getExpedicion($number);
			} else {
				*/
			//Las respuestas pasan a estar almacenadas en base de datos, no rescatamos cada vez que entramos a un pedido
			if (1 == 1) {
				$getparam_id_order = filter_input(INPUT_GET, 'id_order', FILTER_SANITIZE_NUMBER_INT);
				//Comprobamos con NULL porque Prestashop tiene un bug: cuando se cambia el estado del pedido no incluye el parametro GET
				//id_order, con lo cual da un error (en modo debug). A parte, este error impide que despues de cambiar el estado del
				//pedido podamos generar el envio en la mensajeria. Cuando al boton "enviar pedido" ni siquiera llega a "hookAdminOrder" y va
				//directamente a la lista de pedidos.
				/*
				if ($getparam_id_order == NULL || Configuration::get('DRCL_ORDER_EXPORDERID') != $getparam_id_order) {
					$checkExp = 0;
				} else {
					$checkExp = 1;
				}
				*/
				if ($DirecLineOders->response && !is_null($DirecLineOders->response) && $DirecLineOders->response != 'null') {				
					$json_response = Tools::jsonDecode($DirecLineOders->response, true);
					$map = $this->mapeado();
					//Si el pedido ha sido enviado en algún momento reemprimimo los datos del último envío. Antes solo era almacenado el último envio
					if (count($json_response) > 1) {
						$smarty->assign(array('checkExp' => 1));
						$smarty->assign(array('showExp' => 1));
					}
					$map_result = $map;
					foreach ($map as $k => $l) {
						if (isset($json_response[$l]) && is_string($json_response[$l])) {
							$map_result[$k] = $json_response[$l];
						} else {
							$map_result[$k] = false;
						}
					}
				/*
					dump($map);
					dump($json_response);
					dump($map_result);
					die;
						*/
					$smarty->assign($map_result);
				} elseif($number != '') {
					$this->StatusErr = 0;
					$this->getExpedicion($number);
				}
				$smarty->assign(array(
					//'checkExp' 					=> $checkExp,
					/*
					'showExp' 					=> Configuration::get('DRCL_ORDER_SHOWEXP'),
					'sendexp_number' 			=> Configuration::get('DRCL_ORDER_SENDEXP_NUMBER'),
					'sendexp_ref' 				=> Configuration::get('DRCL_ORDER_SENDEXP_REF'),
					'sendexp_status' 			=> Configuration::get('DRCL_ORDER_SENDEXP_STATUS'),
					'sendexp_date' 				=> Configuration::get('DRCL_ORDER_SENDEXP_DATE'),
					'sendexp_hour' 				=> Configuration::get('DRCL_ORDER_SENDEXP_HOUR'),
					'sendexp_signature' 		=> Configuration::get('DRCL_ORDER_SENDEXP_SIGNATURE'),
					'sendexp_dni' 				=> Configuration::get('DRCL_ORDER_SENDEXP_DNI'),
					'sendexp_dateexp' 			=> Configuration::get('DRCL_ORDER_SENDEXP_DATEEXP'),
					'sendexp_name' 				=> Configuration::get('DRCL_ORDER_SENDEXP_NAME'),
					'sendexp_remcity' 			=> Configuration::get('DRCL_ORDER_SENDEXP_REMCITY'),
					'sendexp_dest' 				=> Configuration::get('DRCL_ORDER_SENDEXP_DEST'),
					'sendexp_destaddress' 		=> Configuration::get('DRCL_ORDER_SENDEXP_DESTADDRESS'),
					'sendexp_destcp' 			=> Configuration::get('DRCL_ORDER_SENDEXP_DESTCP'),
					'sendexp_destcity' 			=> Configuration::get('DRCL_ORDER_SENDEXP_DESTCITY'),
					'sendexp_destphone' 		=> Configuration::get('DRCL_ORDER_SENDEXP_DESTPHONE'),
					'sendexp_observations' 		=> Configuration::get('DRCL_ORDER_SENDEXP_OBSERVATIONS'),
					'sendexp_bults' 			=> Configuration::get('DRCL_ORDER_SENDEXP_BULTS'),
					'sendexp_peso' 				=> Configuration::get('DRCL_ORDER_SENDEXP_PESO'),
					'sendexp_codeservices' 		=> Configuration::get('DRCL_ORDER_SENDEXP_CODESERVICES'),
					'sendexp_idexp' 			=> Configuration::get('DRCL_ORDER_SENDEXP_IDEXP'),
					'sendexp_viaref'			=> Configuration::get('DRCL_ORDER_SENDEXP_VIAREF'),
					'sendexp_viatypeservice' 	=> Configuration::get('DRCL_ORDER_SENDEXP_VIATYPESERVICE'),
					'sendexp_codeagency' 		=> Configuration::get('DRCL_ORDER_SENDEXP_CODEAGENCY'),
					'sendexp_nameagency' 		=> Configuration::get('DRCL_ORDER_SENDEXP_NAMEAGENCY'),
					'sendexp_phoneagency' 		=> Configuration::get('DRCL_ORDER_SENDEXP_PHONEAGENCY'),
					'sendexp_nameagencyoring' 	=> Configuration::get('DRCL_ORDER_SENDEXP_NAMEAGENCYORING'),
					'sendexp_abrev' 			=> Configuration::get('DRCL_ORDER_SENDEXP_ABREV'),
					'sendexp_saturdaydelivery'	=> '', //Configuration::get('DRCL_ORDER_SENDEXP_SATURDAYDELIVERY'),
					'sendexp_festivedelivery'	=> '', //Configuration::get('DRCL_ORDER_SENDEXP_FESTIVEDELIVERY'),
					'sendexp_management'  		=> Configuration::get('DRCL_ORDER_SENDEXP_MANAGEMENT'),
					'sendexp_returnsend' 		=> Configuration::get('DRCL_ORDER_SENDEXP_RETURNSEND'),
					'sendexp_delegation' 		=> Configuration::get('DRCL_ORDER_SENDEXP_DELEGATION'),
					'sendexp_receiptaccuse'  	=> Configuration::get('DRCL_ORDER_SENDEXP_RECEIPTACCUSE'),
					'emailclient' 				=> Configuration::get('DRCL_ORDER_SENDEXP_EMAILCLIENT'),
					'smsclient' 				=> Configuration::get('DRCL_ORDER_SENDEXP_SMSCLIENT'),
					'emailshop' 				=> Configuration::get('DRCL_ORDER_SENDEXP_EMAILSHOP'),
					'postagedue' 				=> Configuration::get('DRCL_ORDER_SENDEXP_POSTAGEDUE'),
					*/
					'userror' 					=> $usgroup
				));
			}
			$this->admin_order_errors = $admin_order_errors;
			
			return $this->display(__FILE__, 'views/templates/hook/admin_order.tpl');
		}
	}

	public function getAjaxExpeditionForm()
	{
		$id_order = Tools::getValue('id_order');
		$number = $this->getTrackingNumber($id_order);
		if (!$number) {
			return;
		}
		$this->getExpedicion($number);
		$output = $this->display($this->_path, 'views/templates/hook/admin_order.tpl');
		echo Tools::jsonEncode(array(
			'textos' => array(
				'#direclinepanelContent' => $output
			)
		));
		die;
	}

	private function mapeado()
	{
		$array = array(
			'sendexp_number' 			=> 'DRCL_ORDER_SENDEXP_NUMBER',
			'sendexp_ref' 				=> 'DRCL_ORDER_SENDEXP_REF',
			'sendexp_status' 			=> 'DRCL_ORDER_SENDEXP_STATUS',
			'sendexp_date' 				=> 'DRCL_ORDER_SENDEXP_DATE',
			'sendexp_hour' 				=> 'DRCL_ORDER_SENDEXP_HOUR',
			'sendexp_signature' 		=> 'DRCL_ORDER_SENDEXP_SIGNATURE',
			'sendexp_dni' 				=> 'DRCL_ORDER_SENDEXP_DNI',
			'sendexp_dateexp' 			=> 'DRCL_ORDER_SENDEXP_DATEEXP',
			'sendexp_name' 				=> 'DRCL_ORDER_SENDEXP_NAME',
			'sendexp_remcity' 			=> 'DRCL_ORDER_SENDEXP_REMCITY',
			'sendexp_dest' 				=> 'DRCL_ORDER_SENDEXP_DEST',
			'sendexp_destaddress' 		=> 'DRCL_ORDER_SENDEXP_DESTADDRESS',
			'sendexp_destcp' 			=> 'DRCL_ORDER_SENDEXP_DESTCP',
			'sendexp_destcity' 			=> 'DRCL_ORDER_SENDEXP_DESTCITY',
			'sendexp_destphone' 		=> 'DRCL_ORDER_SENDEXP_DESTPHONE',
			'sendexp_observations' 		=> 'DRCL_ORDER_SENDEXP_OBSERVATIONS',
			'sendexp_bults' 			=> 'DRCL_ORDER_SENDEXP_BULTS',
			'sendexp_peso' 				=> 'DRCL_ORDER_SENDEXP_PESO',
			'sendexp_codeservices' 		=> 'DRCL_ORDER_SENDEXP_CODESERVICES',
			'sendexp_idexp' 			=> 'DRCL_ORDER_SENDEXP_IDEXP',
			'sendexp_viaref'			=> 'DRCL_ORDER_SENDEXP_VIAREF',
			'sendexp_viatypeservice' 	=> 'DRCL_ORDER_SENDEXP_VIATYPESERVICE',
			'sendexp_codeagency' 		=> 'DRCL_ORDER_SENDEXP_CODEAGENCY',
			'sendexp_nameagency' 		=> 'DRCL_ORDER_SENDEXP_NAMEAGENCY',
			'sendexp_phoneagency' 		=> 'DRCL_ORDER_SENDEXP_PHONEAGENCY',
			'sendexp_nameagencyoring' 	=> 'DRCL_ORDER_SENDEXP_NAMEAGENCYORING',
			'sendexp_abrev' 			=> 'DRCL_ORDER_SENDEXP_ABREV',
			'sendexp_saturdaydelivery'	=> '', //Configuration::get('DRCL_ORDER_SENDEXP_SATURDAYDELIVERY'),
			'sendexp_festivedelivery'	=> '', //Configuration::get('DRCL_ORDER_SENDEXP_FESTIVEDELIVERY'),
			'sendexp_management'  		=> 'DRCL_ORDER_SENDEXP_MANAGEMENT',
			'sendexp_returnsend' 		=> 'DRCL_ORDER_SENDEXP_RETURNSEND',
			'sendexp_delegation' 		=> 'DRCL_ORDER_SENDEXP_DELEGATION',
			'sendexp_receiptaccuse'  	=> 'DRCL_ORDER_SENDEXP_RECEIPTACCUSE',
			'emailclient' 				=> 'DRCL_ORDER_SENDEXP_EMAILCLIENT',
			'smsclient' 				=> 'DRCL_ORDER_SENDEXP_SMSCLIENT',
			'emailshop' 				=> 'DRCL_ORDER_SENDEXP_EMAILSHOP',
			'postagedue' 				=> 'DRCL_ORDER_SENDEXP_POSTAGEDUE',
			'insuredvalue_value' => 'VALOR_ASEGURADO' //Valor asegurado,
		);
		$array_api = array(
			'DRCL_ORDER_SENDEXP_NUMBER' => 'NUMERO',
			'DRCL_ORDER_SENDEXP_REF' => 'REFERENCIA',

			'DRCL_ORDER_SENDEXP_STATUS' => 'ESTADO',
			'DRCL_ORDER_SENDEXP_DATE' => 'FECHA',
			'DRCL_ORDER_SENDEXP_HOUR' => 'HORA',
			'DRCL_ORDER_SENDEXP_SIGNATURE' => 'FIRMA',
			'DRCL_ORDER_SENDEXP_DNI' => 'DNI',
			'DRCL_ORDER_SENDEXP_DATEEXP' => 'FECHAEXPEDICION',
			'DRCL_ORDER_SENDEXP_NAME' => 'NOMBRE',
			'DRCL_ORDER_SENDEXP_REMCITY' => 'POBLACION_REMITENTE',
			'DRCL_ORDER_SENDEXP_DEST' => 'DESTINATARIO',
			'DRCL_ORDER_SENDEXP_DESTADDRESS' => 'DOMICILIO_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_DESTCP' => 'CDP_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_DESTCITY' => 'POBLACION_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_DESTPHONE' => 'TELEFONO_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_OBSERVATIONS' => 'OBSERVACIONES',
			'DRCL_ORDER_SENDEXP_BULTS' => 'BULTOS',
			'DRCL_ORDER_SENDEXP_PESO' => 'PESO',
			'DRCL_ORDER_SENDEXP_CODESERVICES' => 'CODIGO_TIPOSERVICIO',
			'DRCL_ORDER_SENDEXP_IDEXP' => 'IDEXPEDICION',
			'DRCL_ORDER_SENDEXP_VIAREF' => 'REFERENCIA_VIA',
			'DRCL_ORDER_SENDEXP_VIATYPESERVICE' => 'TIPO_SERVICIO_VIA',
			'DRCL_ORDER_SENDEXP_CODEAGENCY' => 'CODIGO_AGENCIA_DESTINO_VIA',
			'DRCL_ORDER_SENDEXP_NAMEAGENCY' => 'NOMBRE_AGENCIA_DESTINO_VIA',
			'DRCL_ORDER_SENDEXP_PHONEAGENCY' => 'TELEFONO_AGENCIA_DESTINO_VIA',
			'DRCL_ORDER_SENDEXP_NAMEAGENCYORING' => 'NOMBRE_AGENCIA_ORIGEN_VIA',
			'DRCL_ORDER_SENDEXP_ABREV' => 'ABREVIATURA',

			'DRCL_ORDER_SENDEXP_EMAILSHOP' => 'ENVIO_EMAIL_REMITENTE',
			'DRCL_ORDER_SENDEXP_SMSCLIENT' => 'ENVIO_SMS_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_EMAILCLIENT' => 'ENVIO_EMAIL_DESTINATARIO',
			'DRCL_ORDER_SENDEXP_POSTAGEDUE' => 'IMPORTE_DEBIDO',

			'DRCL_ORDER_SENDEXP_MANAGEMENT' => 'GESTION',
			'DRCL_ORDER_SENDEXP_RETURNSEND' => 'ENVIO_CON_RETORNO',
			'DRCL_ORDER_SENDEXP_DELEGATION' => 'RECOGIDA_EN_DELEGACION',
			'DRCL_ORDER_SENDEXP_RECEIPTACCUSE' => 'ACUSE_RECIBO',
		);
		$resutls = array();
		foreach ($array as $k => $l) {
			if (isset($array_api[$l])) {
				$resutls[$k] = $array_api[$l];
			} else {
				$resutls[$k] = $l;
			}
		}

		return $resutls;
	}

	//
	public function runCron()
	{

		if (Configuration::get('DRCL_ENABLED') == 1 && Configuration::get('DRCL_ENABLED_CRON') == 1) {
			//Get all orders delivered but not marked as Delivered
			//Get all orders sent, marked as shipped but with incidences STATUS_SEND
			$orders = array();
			if (Configuration::get('DRCL_STATUS_SEND_CRON'))
				$orders = $this->getOrderIdsByStatus(Configuration::get('DRCL_STATUS_SEND_CRON'));

			//If orders doesn't have a delivered status but are sent, change status
			if (count($orders) > 0) {
				foreach ($orders as $order_id) {
					$order = new Order($order_id);
					$carrier = new Carrier($order->id_carrier);

					if (version_compare(_PS_VERSION_, '1.5', '<')) {
						$carrier_id = $carrier->id;
						$numShipping = $order->shipping_number;
					} else {
						$carrier_id = $carrier->id_reference;
						$order_carrier = new OrderCarrier($order->getIdOrderCarrier());
						$numShipping = $order_carrier->tracking_number;
					}

					if ($this->getCarrierById($carrier_id) && !empty($numShipping)) {

						$result = $this->getStatus($numShipping);
						if ($result != '') {
							$history = new OrderHistory();
							$history->id_order = (int)$order->id;

							switch ($result) {
								case 32768:
									$history->changeIdOrderState(Configuration::get('DRCL_STATUS_DELIVERED_CRON'), $order, true);
									$history->addWithemail();
									break;
								case 4096:
									$history->changeIdOrderState(Configuration::get('DRCL_STATUS_INCIDENCE_CRON'), $order, true);
									$history->addWithemail();
									break;
							}
						}
					}
				}
			}
		}
	}

	private static function getOrderIdsByStatus($id_order_state)
	{
		$sql = "SELECT id_order
				FROM " . _DB_PREFIX_ . "orders o
				WHERE o.current_state IN ('" . $id_order_state . "')
				" . Shop::addSqlRestriction(false, 'o') . "
				ORDER BY invoice_date ASC";

		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

		$orders = array();
		foreach ($result as $order)
			$orders[] = (int)($order['id_order']);
		return $orders;
	}

	private function getStatus($albaran)
	{
		if (Configuration::get('DRCL_ENABLED') != '1') {
			return;
		}

		if (empty($albaran)) {
			error_log("\n\n" . date('d-m-Y H:i:s') . " \nFunction getStatus Received\n " . print_r("shipping_number o tracking_number no está definido" . "\r\n", true), 3, $this->error_file);
		}

		$xml = $this->obtenerExpedicionECommerceSOAP($albaran);
		if ($xml->ERROR) {
			if ($xml->ERROR->CODIGO == 3 && $this->StatusErr == 0) {
				$this->getNewGUID();
				$this->StatusErr++;
				$this->getStatus($albaran);
			} else {
				$cuerpo = "shipping_number o tracking_number :" . $albaran . " GUID :" . Configuration::get('DRCL_GUID');
				error_log("\n\n" . date('d-m-Y H:i:s') . " \nMethod ObtenerExpedicionECommerce Sent\n " . print_r($cuerpo . "\r\n", true), 3, $this->error_file);
				error_log("\n\n" . date('d-m-Y H:i:s') . " \nMethod ObtenerExpedicionECommerce Received\n " . print_r($xml . "\r\n", true), 3, $this->error_file);
				return "";
			}
		} else {
			return $xml->EXPEDICION->ENESTADO;
		}
	}

	/**
	 * Function getCarrierById
	 *
	 * Get info of the choosed carrier in the order.
	 * If carrier choosed is not enabled for services, it returns null
	 *
	 * @param (int) (id_reference) Order carrier ID
	 * @return (array/null) carrier info or null
	 */
	private function getCarrierById($id_reference)
	{
		$_carriers = unserialize(Configuration::get('DRCL_SERVICES_TYPE'));

		if (isset($_carriers[$id_reference]) && $_carriers[$id_reference]['enabled'] == 1)
			return $_carriers[$id_reference];

		return null;
	}

	private function postAdminValidator()
	{
		Configuration::updateValue('DRCL_ENABLED', Tools::getValue('drcl_enabled'));
		Configuration::updateValue('DRCL_DEBUG', Tools::getValue('drcl_debug'));
		if (Tools::getValue('drcl_enabled') == 1) {
			if (!Tools::getValue('drcl_user')) {
				$this->postErrors[] = $this->l('Usuario no puede estar vacio');
			} else {
				Configuration::updateValue('DRCL_USER', Tools::getValue('drcl_user'));
			}
			if (!Tools::getValue('drcl_password')) {
				$this->postErrors[] = $this->l('Contraseña no puede estar vacio');
			} else {
				Configuration::updateValue('DRCL_PASSWORD', Tools::getValue('drcl_password'));
			}
		}

		if (Tools::getValue('drcl_url_webservice')) {
			Configuration::updateValue('DRCL_URL_WEBSERVICE', Tools::getValue('drcl_url_webservice'));
		}
		if (Tools::getValue('drcl_url_tracing')) {
			Configuration::updateValue('DRCL_URL_TRACING', Tools::getValue('drcl_url_tracing'));
		}

		Configuration::updateValue('RecogerCliente', Tools::getValue('RecogerCliente'));

		if (Tools::getValue('drcl_enabled') == 1) {
			if (Tools::getValue('drcl_user') && Tools::getValue('drcl_password')) {
				$this->validarUsuarioSOAP(Tools::getValue('drcl_user'), Tools::getValue('drcl_password'));
			}
		} elseif (Tools::getValue('drcl_enabled') == 0) {
			if (Tools::getValue('drcl_user') && Tools::getValue('drcl_password')) {
				$this->desconectarUsuarioSOAP(Tools::getValue('drcl_user'), Tools::getValue('drcl_password'), '');
			}
		}
		if (Tools::getValue('drcl_payreem_module')) {
			Configuration::updateValue('DRCL_PAYREEM_MODULE', implode(',', Tools::getValue('drcl_payreem_module')));
		} else {
			Configuration::updateValue('DRCL_PAYREEM_MODULE', '');
		}
		if (Tools::getValue('weight_unit')) {
			Configuration::updateValue('DRCL_WEIGHT_UNIT', Tools::getValue('weight_unit'));
		} else {
			$this->postErrors['DRCL_WEIGHT_UNIT'] = $this->l('Debe seleccionar una unidad de peso');
		}

		Configuration::updateValue('DRCL_CURRENCY_ID', Tools::getValue('drcl_currency_id'));

		$campo = 'Número de productos por bulto';
		if (Tools::getValue('drcl_nproducts_buld') >= 0) {
			if (is_numeric(Tools::getValue('drcl_nproducts_buld'))) {
				if (intval(Tools::getValue('drcl_nproducts_buld')) >= 0) {
					Configuration::updateValue('DRCL_NPRODUCTS_BULT', Tools::getValue('drcl_nproducts_buld'));
				} else {
					$this->postErrors[] = $this->l('No se permiten valores negativos para el campo "' . $campo . '" (' . Tools::getValue('drcl_nproducts_buld') . ')');
				}
			} elseif (strlen(trim(Tools::getValue('drcl_nproducts_buld'))) == 0) {
				Configuration::updateValue('DRCL_NPRODUCTS_BULT', 0);
			} else {
				$this->postErrors[] = $this->l('El valor ingresado no es correcto para el campo "' . $campo . '" (' . Tools::getValue('drcl_nproducts_buld') . ')');
			}
		} else {
			$this->postErrors[] = $this->l('El valor ingresado no es correcto para el campo "' . $campo . '" (' . Tools::getValue('drcl_nproducts_buld') . ')');
		}

		$campo = "Email con aviso a clientes por estados";
		if (Tools::getValue('drcl_status_emailclient') >= 0) {
			$_res =	"";
			$_error = 0;
			$_array = explode(';', (strlen(trim(Tools::getValue('drcl_status_emailclient'))) == 0 ? 0 : trim(Tools::getValue('drcl_status_emailclient'))));
			$_no = "";
			foreach ($_array as $val) :
				if (is_numeric($val)) {
					if (in_array($val, explode(";", str_replace(" ", ";", trim($_res))))) {
					} else {
						if (in_array($val, explode(";", $this->eOk)))
							$_res =	$_res . " " . $val;
						else {
							$_error++;
							$_no = "Error";
							break;
						}
					}
				} else {
					$_error++;
				}
			endforeach;
			if ($_error === 0) {
				Configuration::updateValue('DRCL_STATUS_EMAILCLIENT', str_replace(" ", ";", trim($_res)));
			} else {
				if ($_no == "")
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_emailclient') . ')');
				else
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" contiene un valor no valido: (' . $val . '), datos ingresados : (' . Tools::getValue('drcl_status_emailclient') . ')');
			}
		} else {
			$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_emailclient') . ')');
		}

		$campo = "SMS con aviso a clientes por estados";
		if (Tools::getValue('drcl_status_smsclient') >= 0) {
			$_res =	"";
			$_error = 0;
			$_array = explode(';', (strlen(trim(Tools::getValue('drcl_status_smsclient'))) == 0 ? 0 : trim(Tools::getValue('drcl_status_smsclient'))));
			foreach ($_array as $val) :
				if (is_numeric($val)) {
					if (in_array($val, explode(";", str_replace(" ", ";", trim($_res))))) {
					} else {
						if (in_array($val, explode(";", $this->eOk)))
							$_res =	$_res . " " . $val;
						else {
							$_error++;
							$_no = "Error";
							break;
						}
					}
				} else {
					$_error++;
				}
			endforeach;
			if ($_error === 0) {
				Configuration::updateValue('DRCL_STATUS_SMSCLIENT', str_replace(" ", ";", trim($_res)));
			} else {
				if ($_no == "")
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_smsclient') . ')');
				else
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" contiene un valor no valido: (' . $val . '), datos ingresados : (' . Tools::getValue('drcl_status_smsclient') . ')');
			}
		} else {
			$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_smsclient') . ')');
		}

		$campo = "Email con aviso a tienda por estados";
		if (Tools::getValue('drcl_status_emailshop') >= 0) {
			$_res =	"";
			$_error = 0;
			$_array = explode(';', (strlen(trim(Tools::getValue('drcl_status_emailshop'))) == 0 ? 0 : trim(Tools::getValue('drcl_status_emailshop'))));
			foreach ($_array as $val) :
				if (is_numeric($val)) {
					if (in_array($val, explode(";", str_replace(" ", ";", trim($_res))))) {
					} else {
						if (in_array($val, explode(";", $this->eOk)))
							$_res =	$_res . " " . $val;
						else {
							$_error++;
							$_no = "Error";
							break;
						}
					}
				} else {
					$_error++;
				}
			endforeach;
			if ($_error === 0) {
				Configuration::updateValue('DRCL_STATUS_EMAILSHOP', str_replace(" ", ";", trim($_res)));
			} else {
				if ($_no == "")
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_emailshop') . ')');
				else
					$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" contiene un valor no valido: (' . $val . '), datos ingresados : (' . Tools::getValue('drcl_status_emailshop') . ')');
			}
		} else {
			$this->postErrors[] = $this->l('Los datos introducidos en el campo "' . $campo . '" no tienen el formato correcto: (' . Tools::getValue('drcl_status_emailshop') . ')');
		}

		/*
		if(Tools::getValue('drcl_delivery_saturday')){
			Configuration::updateValue('DRCL_DELIVERY_SATURDAY', Tools::getValue('drcl_delivery_saturday'));
		}else{
			if(Tools::getValue('drcl_delivery_saturday') == ''){
				Configuration::updateValue('DRCL_DELIVERY_SATURDAY', Tools::getValue('drcl_delivery_saturday'));
			};
		};
		
		if(Tools::getValue('drcl_delivery_festive')){
			Configuration::updateValue('DRCL_DELIVERY_FESTIVE', Tools::getValue('drcl_delivery_festive'));
		}else{
			if(Tools::getValue('drcl_delivery_festive') == ''){
				Configuration::updateValue('DRCL_DELIVERY_FESTIVE', Tools::getValue('drcl_delivery_festive'));
			};
		};
		*/

		if (Tools::getValue('drcl_postage_due')) {
			Configuration::updateValue('DRCL_POSTAGE_DUE', Tools::getValue('drcl_postage_due'));
		} else {
			if (Tools::getValue('drcl_postage_due') == '') {
				Configuration::updateValue('DRCL_POSTAGE_DUE', Tools::getValue('drcl_postage_due'));
			}
		}

		if (Tools::getValue('drcl_return_send')) {
			Configuration::updateValue('DRCL_RETURN_SEND', Tools::getValue('drcl_return_send'));
		} else {
			if (Tools::getValue('drcl_return_send') == '') {
				Configuration::updateValue('DRCL_RETURN_SEND', Tools::getValue('drcl_return_send'));
			}
		}

		if (Tools::getValue('drcl_collection_delegation')) {
			Configuration::updateValue('DRCL_COLLECTION_DELEGATION', Tools::getValue('drcl_collection_delegation'));
		} else {
			if (Tools::getValue('drcl_collection_delegation') == '') {
				Configuration::updateValue('DRCL_COLLECTION_DELEGATION', Tools::getValue('drcl_collection_delegation'));
			}
		}

		if (Tools::getValue('drcl_receipt_accuse')) {
			Configuration::updateValue('DRCL_RECEIPT_ACCUSE', Tools::getValue('drcl_receipt_accuse'));
		} else {
			if (Tools::getValue('drcl_receipt_accuse') == '') {
				Configuration::updateValue('DRCL_RECEIPT_ACCUSE', Tools::getValue('drcl_receipt_accuse'));
			}
		}

		if (Tools::getValue('drcl_management')) {
			Configuration::updateValue('DRCL_MANAGEMENT', Tools::getValue('drcl_management'));
		} else {
			if (Tools::getValue('drcl_management') == '') {
				Configuration::updateValue('DRCL_MANAGEMENT', Tools::getValue('drcl_management'));
			}
		}

		/*if(Tools::getValue('drcl_photo_id')){
			Configuration::updateValue('DRCL_PHOTO_ID', Tools::getValue('drcl_photo_id'));
		}else{
			if(Tools::getValue('drcl_photo_id') == ''){
				Configuration::updateValue('DRCL_PHOTO_ID', Tools::getValue('drcl_photo_id'));
			};
		};*/

		$campo = "Valor asegurado";
		if (Tools::getValue('drcl_insured_value') != null) {
			$_res = "0";
			if (is_numeric(Tools::getValue('drcl_insured_value'))) {
				if (intval(Tools::getValue('drcl_insured_value')) >= 0) {
					$val = number_format(str_replace(',', '.', Tools::getValue('drcl_insured_value')), 2);
					Configuration::updateValue('DRCL_INSURED_VALUE', $val);
				} else {
					$this->postErrors[] = $this->l('El valor ingresado para el campo "' . $campo . '" no puede ser negativo. (' . Tools::getValue('drcl_insured_value') . ')');
				}
			} elseif (strlen(trim(Tools::getValue('drcl_insured_value'))) == 0) {
				Configuration::updateValue('DRCL_INSURED_VALUE', $_res);
			} else {
				$this->postErrors[] = $this->l('El valor ingresado para el campo "' . $campo . '" no es correcto. (' . Tools::getValue('drcl_insured_value') . ')');
			}
		}

		if (Tools::getValue('drcl_autochange_statussend')) {
			Configuration::updateValue('DRCL_AUTOCHANGE_STATUSSEND', Tools::getValue('drcl_autochange_statussend'));
		} else {
			if (Tools::getValue('drcl_autochange_statussend') == '') {
				Configuration::updateValue('DRCL_AUTOCHANGE_STATUSSEND', Tools::getValue('drcl_autochange_statussend'));
			}
		}

		if (Tools::getValue('drcl_autostatussend')) {
			Configuration::updateValue('DRCL_AUTOSTATUSSEND', Tools::getValue('drcl_autostatussend'));
		}

		if (Tools::getValue('drcl_manualchange_statuscancel')) {
			Configuration::updateValue('DRCL_MANUALCHANGE_STATUSCANCEL', Tools::getValue('drcl_manualchange_statuscancel'));
		} else {
			if (Tools::getValue('drcl_manualchange_statuscancel') == '') {
				Configuration::updateValue('DRCL_MANUALCHANGE_STATUSCANCEL', Tools::getValue('drcl_manualchange_statuscancel'));
			}
		}

		if (Tools::getValue('drcl_manualstatuscancel')) {
			Configuration::updateValue('DRCL_MANUALSTATUSCANCEL', Tools::getValue('drcl_manualstatuscancel'));
		}

		Configuration::updateValue('DRCL_CANARIAS_CODE', Tools::getValue('drcl_canarias_code'));
		Configuration::updateValue('DRCL_BALEARES_CODE', Tools::getValue('drcl_baleares_code'));
		Configuration::updateValue('DRCL_CEUTA_CODE', Tools::getValue('drcl_ceuta_code'));
		Configuration::updateValue('DRCL_MELILLA_CODE', Tools::getValue('drcl_melilla_code'));
		Configuration::updateValue('DRCL_ANDORRA_CODE', Tools::getValue('drcl_andorra_code'));
		Configuration::updateValue('DRCL_GIBRALTAR_CODE', Tools::getValue('drcl_gibraltar_code'));
		Configuration::updateValue('DRCL_INTERNACIONAL_CODE', Tools::getValue('drcl_internacional_code'));

		if (Tools::getValue('drcl_service_type')) {
			$json = json_encode(Tools::getValue('drcl_service_type'), true);
			$validar = 0;
			$cont = 0;
			$jsonResul = new RecursiveIteratorIterator(
				new RecursiveArrayIterator(json_decode($json, TRUE)),
				RecursiveIteratorIterator::SELF_FIRST
			);

			foreach ($jsonResul as $key => $val) {
				if (is_array($val)) {
					$validar = 0;
					$cont++;
					$IsError = 0;
					$name = "";
				} else {
					if ($key == "enabled" && $val == "1")
						$validar = 1;
					if ($key == "name")
						$name = $val;
					if ($validar == 1) {
						switch ($key) {
							case "code":
								if (trim($val) == "") {
									$IsError++;
									$this->postErrors[] = $this->l('El campo "Código del servicio" del tipo de servicio "' . $name . '" no puede quedar en blanco o vacío.' . "$val");
								}
								break;
							case "codename":
								if (trim($val) == "") {
									$IsError++;
									$this->postErrors[] = $this->l('El campo "Nombre del servicio" del tipo de servicio "' . $name . '" no puede quedar en blanco o vacío.' . "$val");
								}
								break;
						}
					}
				}
			}
			if ($IsError == 0) {
				Configuration::updateValue('DRCL_SERVICES_TYPE', serialize(Tools::getValue('drcl_service_type')));
			}
		}

		Configuration::updateValue('DRCL_ENABLED_CRON', Tools::getValue('drcl_enabled_cron'));

		if (Tools::getValue('drcl_status_send_cron') != null) {
			Configuration::updateValue('DRCL_STATUS_SEND_CRON', implode(";", Tools::getValue('drcl_status_send_cron')));
		} else {
			Configuration::updateValue('DRCL_STATUS_SEND_CRON', Tools::getValue('drcl_status_send_cron'));
		}

		Configuration::updateValue('DRCL_STATUS_DELIVERED_CRON', Tools::getValue('drcl_status_delivered_cron'));
		Configuration::updateValue('DRCL_STATUS_INCIDENCE_CRON', Tools::getValue('drcl_status_incidence_cron'));
	}

	private function validarUsuarioSOAP($user, $password)
	{
		try {
			$params = array();
			$params['Nombre'] = $user;
			$params['Password'] = $password;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->ValidarUsuarioECommerce($params);
			$xml = simplexml_load_string($result->ValidarUsuarioECommerceResult);
			if ($xml->ERROR) {
				switch ($xml->ERROR->CODIGO) {
					case "1401":
						$result = $client->DesconectarUsuarioBPoint($params);
						if ($result->DesconectarUsuarioBPointResult) {
							Configuration::deleteByName('DRCL_GUID');
						}
						$this->postAdminValidator();
						break;
					default:
						$this->postErrors[] = $this->l("Contacte con su oficina de mensajería " . utf8_decode($xml->ERROR->MENSAJE) . "." . $xml->ERROR->CODIGO);
						break;
				}
			} else {
				Configuration::updateValue('DRCL_GUID', $xml->GUID);
			}
		} catch (SoapFault $fault) {
			$xml = $this->GetErrorDefault();
			$this->postErrors[] = $this->l(utf8_decode($xml->ERROR->MENSAJE));
		}
	}

	private function desconectarUsuarioSOAP($user, $password, $orden)
	{
		try {
			$params = array();
			$params['Nombre'] = $user;
			$params['Password'] = $password;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->DesconectarUsuarioBPoint($params);
			if ($result->DesconectarUsuarioBPointResult) {
				Configuration::deleteByName('DRCL_GUID');
			}
		} catch (SoapFault $fault) {
			if ($orden == 'uninstall') {
			} else {
				$xml = $this->GetErrorDefault();
				$this->postErrors[] = $this->l(utf8_decode($xml->ERROR->MENSAJE));
			}
		}
	}

	private function imprimirEtiquetaSOAP($guid, $numexp)
	{
		try {
			$params = array();
			$params['GUID'] = $guid;
			$params['Numero'] = $numexp;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->ImprimirEtiqueta($params);
			if (Configuration::get('DRCL_DEBUG') == 1) {
				ob_start();
				Configuration::updateValue('DRCL_DEBUG_RESULT', var_export($result, true));
				ob_end_flush();
			}
			$xml = simplexml_load_string($result->ImprimirEtiquetaResult);
		} catch (SoapFault $fault) {
			$xml = $this->GetErrorDefault();
		}
		return $xml;
	}

	private function grabarExpedicionExpresSOAP($guid, $Remitente, $RecogidaReferencia, $RecogidaCodigoDomicilioMemorizado, $RecogidaDireccion, $RecogidaTipoDireccion, $RecogidaNumeroDireccion, $RecogidaCodigoPostal, $RecogidaPais, $RecogidaPoblacion, $RecogidaPisoDireccion, $RecogidaNombre2, $RecogidaMasDatos, $RecogidaTelefono, $RecogidaEmail, $RecogidaObservacion, $RecogidaMovil, $RecogidaNif, $RecogidaPointer, $RecogidaAvisoEmail, $RecogidaAvisoSms, $RecogidaCodigoTipoServicio, $RecogidaGestion, $RecogidaFecha, $RecogidaHoraInicial, $RecogidaHoraFinal, $RecogerCliente, $Destinatario, $EntregaCodigoDomicilioMemorizado, $EntregaDireccion, $EntregaTipoDireccion, $EntregaNumeroDireccion, $EntregaCodigoPostal, $EntregaPais, $EntregaPoblacion, $EntregaPisoDireccion, $EntregaNombre2, $EntregaMasDatos, $EntregaTelefono, $EntregaEmail, $EntregaObservacion, $EntregaMovil, $EntregaNif, $EntregaPointer, $EntregaAvisoEmail, $EntregaAvisoSms, $EntregaCodigoTipoServicio, $EntregaGestion, $EntregaFecha, $Retorno, $AcuseRecibo, $ImporteValor, $ImporteReembolso, $ImporteCobroACuenta, $ImporteDebido, $BultoTotal, $BultoNumero, $BultoAlto, $BultoAncho, $BultoLargo, $BultoPeso, $BultoCodigoContenido, $BultoObservacion, $BultoReferencia, $Referencia)
	{
		try {
			$params['GUID'] = $guid; // String
			$params['Remitente'] = $Remitente; //string 
			$params['RecogidaReferencia'] = $RecogidaReferencia; //string 
			$params['RecogidaCodigoDomicilioMemorizado'] = $RecogidaCodigoDomicilioMemorizado; //string 
			$params['RecogidaDireccion'] = $RecogidaDireccion; //string 
			$params['RecogidaTipoDireccion'] = $RecogidaTipoDireccion; //string 
			$params['RecogidaNumeroDireccion'] = $RecogidaNumeroDireccion; //string 
			$params['RecogidaCodigoPostal'] = $RecogidaCodigoPostal; //string 
			$params['RecogidaPais'] = $RecogidaPais; //string 
			$params['RecogidaPoblacion'] = $RecogidaPoblacion; //string 
			$params['RecogidaPisoDireccion'] = $RecogidaPisoDireccion; //string 
			$params['RecogidaNombre2'] = $RecogidaNombre2; //string 
			$params['RecogidaMasDatos'] = $RecogidaMasDatos; //string 
			$params['RecogidaTelefono'] = $RecogidaTelefono; //string 
			$params['RecogidaEmail'] = $RecogidaEmail; //string 
			$params['RecogidaObservacion'] = $RecogidaObservacion; //string 
			$params['RecogidaMovil'] = $RecogidaMovil; //string 
			$params['RecogidaNif'] = $RecogidaNif; //string 
			$params['RecogidaPointer'] = $RecogidaPointer; //string 
			$params['RecogidaAvisoEmail'] = $RecogidaAvisoEmail; //int 
			$params['RecogidaAvisoSms'] = $RecogidaAvisoSms; //int 
			$params['RecogidaCodigoTipoServicio'] = $RecogidaCodigoTipoServicio; //string 
			$params['RecogidaGestion'] = $RecogidaGestion; //boolean 
			$params['RecogidaFecha'] = $RecogidaFecha; //dateTime 
			$params['RecogidaHoraInicial'] = $RecogidaHoraInicial; //dateTime 
			$params['RecogidaHoraFinal'] = $RecogidaHoraFinal; //dateTime 
			$params['RecogerCliente'] = $RecogerCliente; //boolean 
			$params['Destinatario'] = $Destinatario; //string 
			$params['EntregaCodigoDomicilioMemorizado'] = $EntregaCodigoDomicilioMemorizado; //string 
			$params['EntregaDireccion'] = $EntregaDireccion; //string 
			$params['EntregaTipoDireccion'] = $EntregaTipoDireccion; //string 
			$params['EntregaNumeroDireccion'] = $EntregaNumeroDireccion; //string 
			$params['EntregaCodigoPostal'] = $EntregaCodigoPostal; //string 
			$params['EntregaPais'] = $EntregaPais; //string 
			$params['EntregaPoblacion'] = $EntregaPoblacion; //string 
			$params['EntregaPisoDireccion'] = $EntregaPisoDireccion; //string 
			$params['EntregaNombre2'] = $EntregaNombre2; //string 
			$params['EntregaMasDatos'] = $EntregaMasDatos; //string 
			$params['EntregaTelefono'] = $EntregaTelefono; //string 
			$params['EntregaEmail'] = $EntregaEmail; //string 
			$params['EntregaObservacion'] = $EntregaObservacion; //string 
			$params['EntregaMovil'] = $EntregaMovil; //string 
			$params['EntregaNif'] = $EntregaNif; //string 
			$params['EntregaPointer'] = $EntregaPointer; //string 
			$params['EntregaAvisoEmail'] = $EntregaAvisoEmail; //int 
			$params['EntregaAvisoSms'] = $EntregaAvisoSms; //int 
			$params['EntregaCodigoTipoServicio'] = $EntregaCodigoTipoServicio; //string 
			$params['EntregaGestion'] = ($EntregaGestion == 1 ? true : false); //boolean 
			$params['EntregaFecha'] = $EntregaFecha; //dateTime 
			$params['Retorno'] = ($Retorno == 1 ? true : false); //boolean 
			$params['AcuseRecibo'] = ($AcuseRecibo == 1 ? true : false); //boolean 
			$params['ImporteValor'] = $ImporteValor; //double 
			$params['ImporteReembolso'] = $ImporteReembolso; //double 
			$params['ImporteCobroACuenta'] = $ImporteCobroACuenta; //double 
			$params['ImporteDebido'] = $ImporteDebido; //double 
			$params['BultoTotal'] = $BultoTotal; //short 
			$params['BultoNumero'] = $BultoNumero; //short 
			$params['BultoAlto'] = $BultoAlto; //float 
			$params['BultoAncho'] = $BultoAncho; //float 
			$params['BultoLargo'] = $BultoLargo; //float 
			$params['BultoPeso'] = $BultoPeso; //float 
			$params['BultoCodigoContenido'] = $BultoCodigoContenido; //string 
			$params['BultoObservacion'] = $BultoObservacion; //string 
			$params['BultoReferencia'] = $BultoReferencia; //string 
			$params['Referencia'] = $Referencia; //string 

			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->GrabarExpedicionExpresOS($params);

		/*
			dump( (string)simplexml_load_string($result->GrabarExpedicionExpresOSResult)->EXPEDICION->REFERENCIAENTREGA[0]  );
			dump( json_decode( json_encode( $this->obtenerExpedicionECommerceSOAP(   (string)simplexml_load_string($result->GrabarExpedicionExpresOSResult)->EXPEDICION->REFERENCIAENTREGA[0]   )   )));
			dump($params);
			die;
		*/
			if (Configuration::get('DRCL_DEBUG') == 1) {
				ob_start();
				Configuration::updateValue('DRCL_DEBUG_RESULT', var_export($result, true));
				ob_end_flush();
			}
			$xml = simplexml_load_string($result->GrabarExpedicionExpresOSResult);

			/*
			dump($params);
			dump( simplexml_load_string($result->GrabarExpedicionExpresOSResult)  );
			$numRef = $xml->EXPEDICION->REFERENCIAENTREGA;
			$result_obtenerExpedicion = $this->obtenerExpedicionECommerceSOAP($numRef);
			dump($result_obtenerExpedicion);
			die;
			*/
		} catch (SoapFault $fault) {
			/*
			dump($fault->faultstring);
			dump($params);
			dump($fault);
			die;
			*/
			$xml = $this->GetErrorDefault();
		}

		return $xml;
	}

	private function getNewGUID()
	{
		try {
			$params = array();
			$params['Nombre'] = Configuration::get('DRCL_USER'); //$user
			$params['Password'] = Configuration::get('DRCL_PASSWORD'); //$password;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->DesconectarUsuarioBPoint($params);

			if ($result->DesconectarUsuarioBPointResult) {
				Configuration::deleteByName('DRCL_GUID');
			}
			if (Configuration::get('DRCL_GUID') == '') {
				$result = $client->ValidarUsuarioECommerce($params);
				$xml = simplexml_load_string($result->ValidarUsuarioECommerceResult);

				if ($xml->ERROR) {
					$this->admin_order_errors[] = $this->l(utf8_decode($xml->ERROR->MENSAJE) . " Contacte con su oficina de mensajería.");
				} else {
					Configuration::updateValue('DRCL_GUID', $xml->GUID);
				}
			}
		} catch (SoapFault $fault) {
			$xml = $this->GetErrorDefault();
			$this->admin_order_errors[] = $this->l($xml->ERROR->MENSAJE);
		}
	}

	private function eliminarExpedicionSOAP($guid, $numexp)
	{
		try {
			$params = array();
			$params['GUID'] = $guid;
			$params['ReferenciaEntrega'] = $numexp;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->EliminarExpedicion($params);
			$xml = simplexml_load_string($result->EliminarExpedicionResult);
		} catch (SoapFault $fault) {
			$xml = $this->GetErrorDefault();
		}
		return $xml;
	}

	private function obtenerExpedicionPorNumeroSOAP($guid, $ref)
	{
		$params = array();
		$params['GUID'] = Configuration::get('DRCL_GUID');
		$params['Numero'] = $ref;
		$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
		$result = $client->ObtenerExpedicionPorNumero($params);
		if (Configuration::get('DRCL_DEBUG') == 1) {
			ob_start();
			Configuration::updateValue('DRCL_DEBUG_RESULT', var_export($result, true));
			ob_end_flush();
		}
		return simplexml_load_string($result->ObtenerExpedicionPorNumeroResult);
	}

	private function obtenerExpedicionECommerceSOAP($ref)
	{
		try {
			$params = array();
			$params['GUID'] = Configuration::get('DRCL_GUID');
			$params['Numero'] = $ref;
			$client = new SoapClient(Configuration::get('DRCL_URL_WEBSERVICE'), $params);
			$result = $client->ObtenerExpedicionECommerce($params);
			if (Configuration::get('DRCL_DEBUG') == 1) {
				ob_start();
				Configuration::updateValue('DRCL_DEBUG_RESULT', var_export($result, true));
				ob_end_flush();
			}
			$xml = simplexml_load_string($result->ObtenerExpedicionECommerceResult);
		} catch (SoapFault $fault) {
			$xml = $this->GetErrorDefault();
		}

		return $xml;
	}

	private function getCodeStatus($code)
	{
		switch ($code) {
			case 1:
				$status = $this->l('Introducido');
				break;
			case 2:
				$status = $this->l('Pendiente de Revisión');
				break;
			case 4:
				$status = $this->l('Pendiente de Validar');
				break;
			case 8:
				$status = $this->l('Validado');
				break;
			case 16:
				$status = $this->l('Falta Cliente');
				break;
			case 32:
				$status = $this->l('Verificado');
				break;
			case 64:
				$status = $this->l('Cargado');
				break;
			case 128:
				$status = $this->l('En Transito');
				break;
			case 256:
				$status = $this->l('Localizado');
				break;
			case 512:
				$status = $this->l('Falta');
				break;
			case 1024:
				$status = $this->l('Sobra');
				break;
			case 2048:
				$status = $this->l('Descargado');
				break;
			case 4096:
				$status = $this->l('Incidencia');
				break;
			case 8192:
				$status = $this->l('Pendiente En Agencia');
				break;
			case 16384:
				$status = $this->l('En Reparto');
				break;
			case 32768:
				$status = $this->l('Entregado');
				break;
			case 65536:
				$status = $this->l('Devuelto');
				break;
			case 131072:
				$status = $this->l('Canalizado Nuevo Destino');
				break;
			case 262144:
				$status = $this->l('Destruido');
				break;
			case 524288:
				$status = $this->l('Perdido');
				break;
			case 1048576:
				$status = $this->l('Fallido');
				break;
			case 2097152:
				$status = $this->l('Eliminado');
				break;
			default:
				$status = 'Estado Desconocido';
		}
		return $status;
	}

	private function getCodeError($code, $message)
	{
		return 'ERROR ' . $code . ' - ' . utf8_decode($message);
	}

	private function getMessage($msg)
	{
		$resp = "";
		$campo  = explode(" ", str_replace("'", "", $msg));
		switch ($campo[2]) {
			case "RecogidaDireccion":
				$resp = "El parámetro 'Dirección de la tienda (línea 1)' es obligatorio";
				break;
			case "RecogidaCodigoPostal":
				$resp = "El parámetro 'Código postal/Zip' es obligatorio";
				break;
			case "RecogidaPais":
				$resp = "El parámetro 'País' es obligatorio";
				break;
			case "RecogidaPoblacion":
				$resp = "El parámetro 'Ciudad' es obligatorio";
				break;
		}
		return  $resp;
	}


	private function getExpedicion($numexp)
	{

		if ($this->StatusErr > 1) {
			$this->admin_order_errors[] = $this->l('No se ha encontrado el envío con referencia de entrega ("' . $numexp . '"). Contacte con su oficina de mensajería.');
			$this->smarty->assign(array(
				'errors' 	=> $this->admin_order_errors,
				'checkExp'	=> 1,
				'showExp' 	=> 1
			));
		} else {
			$xml = $this->obtenerExpedicionECommerceSOAP($numexp);
			if ($xml->ERROR) {
				if ($xml->ERROR->CODIGO == 3) {
					$this->getNewGUID();
					$this->StatusErr++;
					$this->getExpedicion($numexp);
				} else if ($xml->ERROR->CODIGO == 800027) {
					$this->admin_order_errors[] = $this->l(utf8_decode($xml->ERROR->MENSAJE));
					$this->smarty->assign(array(
						'errors' 	=> $this->admin_order_errors,
						'checkExp'	=> 1,
						'showExp' 	=> 1
					));
				} else {
					$this->admin_order_errors[] = $this->l('No se ha encontrado el envío con referencia de entrega ("' . $numexp . '"). Contacte con su oficina de mensajería.');
					$this->smarty->assign(array(
						'errors' 	=> $this->admin_order_errors,
						'checkExp'	=> 1,
						'showExp' 	=> 1
					));
				}
			} else if (empty($xml->EXPEDICION)) {
				$this->smarty->assign(array(
					'errors' 	=> $this->admin_order_errors,
					'checkExp'	=> 1,
					'showExp' 	=> 1
				));
			} else {
				$Expedicion = $xml->EXPEDICION;
				$this->smarty->assign(array(
					'checkExp' 					=> 1,
					'showExp' 					=> 1,
					'cashdelivery_value' 		=> $Expedicion->IMPORTE_REEMBOLSO,
					'emailclient' 				=> $Expedicion->ENVIO_EMAIL_DESTINATARIO,
					'emailclient_value' 		=> $Expedicion->EMAIL_DESTINATARIO,
					'smsclient' 				=> $Expedicion->ENVIO_SMS_DESTINATARIO,
					'emailshop' 				=> $Expedicion->ENVIO_EMAIL_REMITENTE,
					'postagedue' 				=> $Expedicion->IMPORTE_DEBIDO,
					'sendexp_number' 			=> $Expedicion->NUMERO,
					'sendexp_ref' 				=> $Expedicion->REFERENCIA,
					'sendexp_status' 			=> $Expedicion->ESTADO,
					'sendexp_date' 				=> $Expedicion->FECHA,
					'sendexp_hour' 				=> $Expedicion->HORA,
					'sendexp_signature' 		=> $Expedicion->FIRMA,
					'sendexp_dni' 				=> $Expedicion->DNI,
					'sendexp_dateexp' 			=> $Expedicion->FECHAEXPEDICION,
					'sendexp_name' 				=> $Expedicion->NOMBRE,
					'sendexp_remcity' 			=> $Expedicion->POBLACION_REMITENTE,
					'sendexp_dest' 				=> $Expedicion->DESTINATARIO,
					'sendexp_destaddress' 		=> $Expedicion->DOMICILIO_DESTINATARIO,
					'sendexp_destcp' 			=> $Expedicion->CDP_DESTINATARIO,
					'sendexp_destcity' 			=> $Expedicion->POBLACION_DESTINATARIO,
					'sendexp_destphone' 		=> $Expedicion->TELEFONO_DESTINATARIO,
					'sendexp_observations' 		=> $Expedicion->OBSERVACIONES,
					'sendexp_bults' 			=> $Expedicion->BULTOS,
					'sendexp_peso' 				=> $Expedicion->PESO,
					'sendexp_codeservices' 		=> $Expedicion->CODIGO_TIPOSERVICIO,
					'sendexp_idexp' 			=> $Expedicion->IDEXPEDICION,
					'sendexp_viaref'			=> $Expedicion->REFERENCIA_VIA,
					'sendexp_viatypeservice' 	=> $Expedicion->TIPO_SERVICIO_VIA,
					'sendexp_codeagency' 		=> $Expedicion->CODIGO_AGENCIA_DESTINO_VIA,
					'sendexp_nameagency' 		=> $Expedicion->NOMBRE_AGENCIA_DESTINO_VIA,
					'sendexp_phoneagency' 		=> $Expedicion->TELEFONO_AGENCIA_DESTINO_VIA,
					'sendexp_nameagencyoring' 	=> $Expedicion->NOMBRE_AGENCIA_ORIGEN_VIA,
					'sendexp_abrev' 			=> $Expedicion->ABREVIATURA,
					'sendexp_saturdaydelivery'	=> ((trim(strtolower($Expedicion->ENTREGA_EN_SABADO)) == 'true') ? 1 : 0),
					'sendexp_festivedelivery'	=> ((trim(strtolower($Expedicion->ENTREGA_EN_FESTIVO)) == 'true') ? 1 : 0),
					'sendexp_management'  		=> ((trim(strtolower($Expedicion->GESTION)) == 'true') ? 1 : 0),
					'sendexp_returnsend' 		=> ((trim(strtolower($Expedicion->ENVIO_CON_RETORNO)) == 'true') ? 1 : 0),
					'sendexp_delegation' 		=> ((trim(strtolower($Expedicion->RECOGIDA_EN_DELEGACION)) == 'true') ? 1 : 0),
					'sendexp_receiptaccuse'  	=> ((trim(strtolower($Expedicion->ACUSE_RECIBO)) == 'true') ? 1 : 0),
					'insuredvalue_value'		=> $Expedicion->VALOR_ASEGURADO

				));
			}
		}
	}

	/**
	 * Devuelve el numero de expedicion de un peddo de Prestashop. 
	 * Segun la version de Prestashop instalada. Lo recupera de un sitio u otro.
	 * Para versiones  < 1.5 accede a ps_orders->shipping_number
	 * Para versiones >= 1.5 accede a ps_order_carrier->tracking_number
	 * @param int $id_order ID del pedido de Prestashop
	 * @return string Numero de expedicion
	 * @author Oliver
	 */
	private function getTrackingNumber($id_order)
	{
		$number = '';
		$order = new Order($id_order);
		if (version_compare(_PS_VERSION_, '1.5', '<')) {
			$number = $order->shipping_number;
		} else {
			//$order_carrier = new OrderCarrier($order->id);
			$order_carrier = new OrderCarrier($order->getIdOrderCarrier());
			$number = $order_carrier->tracking_number;
		}

		return $number;
	}

	/**
	 * Establece el numero de expedicion de un pedido de Prestashop
	 * Para versiones  < 1.5 accede a ps_orders->shipping_number
	 * Para versiones >= 1.5 accede a ps_order_carrier->tracking_number
	 * @param int $id_order ID del pedido de Prestashop (ps_orders->shipping_number)
	 * @param string $number
	 * @author Oliver
	 */
	private function setTrackingNumber($id_order, $number)
	{
		$order = new Order($id_order);
		if (version_compare(_PS_VERSION_, '1.5', '<')) {
			$order->shipping_number = $number;
			$order->update();
		} else {
			//$order_carrier = new OrderCarrier($order->id);
			$order_carrier = new OrderCarrier($order->getIdOrderCarrier());
			$order_carrier->tracking_number = $number;
			$order_carrier->update();
		}
	}

	/**
	 * Elimina el numero de seguimiento de un pedido de Prestashop
	 * Para versiones  < 1.5 accede a ps_orders->shipping_number
	 * Para versiones >= 1.5 accede a ps_order_carrier->tracking_number
	 * @param int $id_order ID del pedido de Prestashop (ps_orders->shipping_number)
	 * @author Oliver
	 */
	private function deleteTrackingNumber($id_order)
	{
		$this->setTrackingNumber($id_order, '');
	}

	/**
	 * Obtiene el ID de OrderCarrier a partir de una Order
	 * @param object $order Objeto de Order
	 * @return int ID de OrderCarrier
	 */
	private function getIdOrderCarrier($order)
	{
		if (version_compare(_PS_VERSION_, '1.5', '<')) {
			return (int)Db::getInstance()->getValue('
                SELECT `id_order_carrier`
                FROM `' . _DB_PREFIX_ . 'order_carrier`
                WHERE `id_order` = ' . (int)$order->id);
		} else {
			return $order->getIdOrderCarrier();
		}
	}

	/**
	 * Actualiza la url del Order Carrier con la que haya guardado en el backend del módulo.
	 * en la sección Configuracion del WebService en el campo URL Seguimiento,
	 * Esto se hace porque al actualizar la url de tracking del transportista (Transporte - Transportistas) 
	 * en prestashop en la V1.6 se duplica el transportista en la tabla ps_carrier manteniendo id_reference aumentando id_carrier.
	 * Como no sabemos como puede llegar a afectarnos es mejor evitar que el cliente tenga que tocar la url de tracking del transportista.
	 * @param (Object) (admin_order_carrier) Objeto Order carrier
	 * @author Juan Antonio
	 */
	private function actualizarUrlOrderCarrier($admin_order_carrier)
	{
		$admin_order_carrier->url = Configuration::get('DRCL_URL_TRACING');
		$admin_order_carrier->update();
	}

	/**
	 * Funcion que crea un Documento XML de error propia para gestionar las soapFault (excepciones de soap)
	 * @return xml Documento XML con el error predefinido 404
	 */
	private function GetErrorDefault()
	{
		$error404 = "<?xml version='1.0' encoding='iso-8859-1'?><GetErrorDefault><ERROR><CODIGO>800027</CODIGO><MENSAJE>ERROR 404 - URL no válida " . Configuration::get('DRCL_URL_WEBSERVICE') . " o Servicio no disponible actualmente. Por favor inténtelo de nuevo pasados unos minutos.</MENSAJE><STACKTRACE>   </STACKTRACE></ERROR></GetErrorDefault>";
		return simplexml_load_string($error404);
	}

	/**
	 * Muestra el contenido de una variable (para debug)
	 * @param string $var_name Nombre de la variable
	 * @param object $var Variable a mostrar
	 * @author Oliver
	 */
	private function var_debug($var_name, $var)
	{
		echo '<pre>';
		echo $var_name . ': ';
		var_dump($var);
		echo '</pre>';
	}

	/**
	 * Muestra un texto (para debug)
	 * @param string $text Texto a mostrar
	 */
	private function text_debug($text)
	{
		echo '<pre>';
		echo $text;
		echo '</pre>';
	}

	public function getModulePath()
	{
		return $this->_path;
	}
}
