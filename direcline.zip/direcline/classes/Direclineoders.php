<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to a commercial license from Jose Mª Gómez Roncero.
 * Use, copy, modification or distribution of this source file without written
 * license agreement from the SARL SMC is strictly forbidden.
 * In order to obtain a license, please contact us: josemariagomezroncero@gmail.com
 * ...........................................................................
 * INFORMATION SUR LA LICENCE D'UTILISATION
 *
 * L'utilisation de ce fichier source est soumise a une licence commerciale
 * concedee par la societe Jose Mª Gómez Roncero.
 * Toute utilisation, reproduction, modification ou distribution du present
 * fichier source sans contrat de licence ecrit de la part de la Jose Mª Gómez Roncero
 * expressement interdite.
 * Pour obtenir une licence, veuillez contacter Jose Mª Gómez Roncero. a l'adresse: josemariagomezroncero@gmail.com
 *
 * @author    Jose Mª Gómez Roncero.
 * @copyright Copyright (c) 2020 Jose Mª Gómez Roncero - Avda de Lorca nº 28 Bajo - Sangonera La Seca (España)
 * @license   Commercial license
 * @package   apmassociations
 * Support by mail:  josemariagomezroncero@gmail.com
*/

if (!defined('_PS_VERSION_'))
    exit;

class DirecLineOders extends ObjectModel
{
    public $id_order;
    public $state;
    public $response;
    public $errors;
    public $errors_html;
    public $date_add;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'direcline_orders',
        'primary' => 'id_order',
        'multilang' => false,
        'fields' => array(
            'id_order' =>               array('type' => self::TYPE_INT, 'required' => true, 'validate' => 'isInt'),
            'state' =>                  array('type' => self::TYPE_INT, 'required' => true, 'validate' => 'isInt'),
            'response' =>               array('type' => self::TYPE_STRING),
            'errors' =>                 array('type' => self::TYPE_STRING),
            'errors_html' =>                 array('type' => self::TYPE_HTML),
            'date_add' =>               array('type' => self::TYPE_DATE),
        ),
    );

    public static function getUpdatableOrders(){

        $sql = "SELECT DISTINCT id_order FROM `"._DB_PREFIX_."direcline_orders` so 
                WHERE ecb != '' AND grupo !='ENTREGADO' AND date_labeled > (DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) ";


        $results =  Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $orders = array();
        foreach($results as $result){
            $orders[] = $result['id_order'];
        }

        return($orders);

    }


    public function exist()
    {
        $sql = "SELECT * FROM `"._DB_PREFIX_."direcline_orders` WHERE id_order = " . (int)$this->id_order;
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        if (count($results) > 0) {
            return true;
        } else {
            return false;
        }
    }

}