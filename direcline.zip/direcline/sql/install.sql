CREATE TABLE IF NOT EXISTS `PREFIX_direcline_orders` (
`id_order` int(10) NOT NULL,
`state` int(3) NOT NULL,
`response` varchar(2000),
`errors` varchar(2000),
`date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (`id_order`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;
